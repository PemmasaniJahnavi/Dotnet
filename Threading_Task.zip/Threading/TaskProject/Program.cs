﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TaskDemo td=new TaskDemo();
            //td.Demo1();
            //td.Demo2();
            //td.Demo3();
            //td.Demo4();
            //td.Demo5();
            td.Demo6();
            Console.Read();
        }
    }
}
