﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskProject
{
    internal class TaskDemo
    {
        public void MyMethod()
        {
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("My method called");
                Thread.Sleep(1000);

            }
        }
        public void Demo1()
        {
            Task t1 = new Task(MyMethod);
            t1.Start();
        }

        public void Demo2()
        {
            Task t1 = Task.Run(() =>
            {
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine("method1 called");
                    Thread.Sleep(1000);
                }
            });
            Task t2 = Task.Run(() =>
            {
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine("method2 called");
                    Thread.Sleep(1000);
                }
            });

            //wait till all tasks are executed
            //Task.WaitAll(t1, t2);
            //Console.WriteLine("Both tasks completed");

            //waits till any of the given tasks executed
            //Task.WaitAny(t1, t2);
            //Console.WriteLine("One of the task completed");

            //allow the continuation of other execution, this is the default one
            Task.WhenAll(t1, t2);
            Console.WriteLine("All tasks executed");

        }

        public void Demo3()
        {
            //calling wait method to execute task2 after task1 completion
            Task t1 = Task.Run(() =>
            {
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine("method1 called");
                    Thread.Sleep(1000);
                }
            });
            t1.Wait();

            Task t2 = Task.Run(() =>
            {
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine("method2 called");
                    Thread.Sleep(1000);
                }
            });

        }

        public void Demo4()
        {
            //using continuewith for sequential execution of tasks
            Task t1 = Task.Run(() =>
            {
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine("method called");
                    Thread.Sleep(1000);
                }
            }).ContinueWith((x) =>
            {
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine("continue called");
                    Thread.Sleep(1000);
                }
            });

        }

        public void Demo5()
        {
            //how to cancel a task
            //we can cancel tasks using timer, cancel method
            CancellationTokenSource c = new CancellationTokenSource();
            c.CancelAfter(5000);

            Task t1 = Task.Run(() =>
            {
                try
                {
                    for (int i = 0; i < 20; i++)
                    {
                        if (c.IsCancellationRequested)
                        {
                            throw new TaskCanceledException("Task has been cancelled");
                        }
                        Console.WriteLine("Task is running");
                        Thread.Sleep(1000);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            });

        }

        public void Demo6()
        {
            //simple scenario use task run or start (not for long running)
            //if long running use - Task.Factory - task scheduler checks if its possible to use ThreadPool to do the job,
            //if not it will create separate dedicated thread for the job
            Task t1=Task.Factory.StartNew(() =>
            {
                Console.WriteLine("parent task started");
                Task.Factory.StartNew(() =>
                {

                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine("Child-1 Executing");
                        Thread.Sleep(1000);
                    }
                }, TaskCreationOptions.AttachedToParent);
                Task.Factory.StartNew(() =>
                {
                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine("Child-2 Executing");
                        Thread.Sleep(1000);
                    }

                },TaskCreationOptions.AttachedToParent);
                });
            t1.Wait();
            Console.WriteLine("parent task completed");
        }
    }
}
