﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Threading
{
    internal class ThreadSyncDemo
    {
        //Using Monitor for Sync
        public void FileHandling()
        {
            Monitor.Enter(this); //only 1 thread can enter inside
            for (int i = 0; i<5;i++)
            {
                Console.WriteLine(Thread.CurrentThread.Name+" "+i);
                Thread.Sleep(1000);
            }
            Monitor.Exit(this);
        }

        public void FileHandling1()
        {
            lock (this)
            {
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine(Thread.CurrentThread.Name + " " + i);
                    Thread.Sleep(1000);
                }
            }          
        }
    }
}
