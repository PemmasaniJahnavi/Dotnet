﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Threading
{
    internal class Assignment
    {
        static Semaphore s = new Semaphore(1,1);
        int n = 0;
        public void show1()
        {
            for (int i = 1; i < 6; i++)
            {
                Console.WriteLine(i);
            }

        }

        public void show2()
        {
            for (int i = 6; i <= 10; i++)
            {
                Console.WriteLine(i);
            }

        }
        public void Sync()
        {
            Monitor.Enter(this);

            for (int i = 0; i < 3; i++)
            {
                n++;
            }
            Monitor.Exit(this);
            Console.WriteLine(n);
        }
    }
}
