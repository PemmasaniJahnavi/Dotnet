﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Threading
{
    internal class SemaphoreDemo
    {
        static Semaphore s=new Semaphore(3,5);

        public void Run()
        {
            for(int i=0;i<10;i++)
            {
                new Thread(DoSomething).Start(i);
            }
        }
        public static void DoSomething(object id)
        {
            Console.WriteLine(id + " wants to access");
            s.WaitOne();
            Console.WriteLine(id+" has access to semaphore");
            Thread.Sleep(1000);
            Console.WriteLine(id+" leaving the semaphore");
            s.Release();
        }

    }
}
