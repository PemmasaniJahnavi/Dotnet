﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Threading
{
    internal class Program
    {

        //static EventWaitHandle handle=new AutoResetEvent(false);
        static EventWaitHandle handle = new ManualResetEvent(false);

        public static void sayHello(object data)
        {
            Console.WriteLine("Inside sayhello func "+data);
            handle.WaitOne();
            Console.WriteLine(data);
        }
        static void Main(string[] args)
        {
            //ThreadDemo td = new ThreadDemo();
            //Thread t = new Thread(td.Worker);
            //t.Start();


            //ThreadPoolDemo tp=new ThreadPoolDemo();
            //ThreadPool.QueueUserWorkItem(tp.m1,"hi");
            //ThreadPool.QueueUserWorkItem(tp.m2,2);
            

            //ThreadSyncDemo ts=new ThreadSyncDemo();
            //Thread t1 = new Thread(ts.FileHandling1);
            //t1.Name = "First";
            //Thread t2= new Thread(ts.FileHandling1);
            //t2.Name = "Second";
            //t1.Start();
            //t2.Start();

            //MutexDemo ob=new MutexDemo();
            //ob.MyApp();

            //SemaphoreDemo sd=new SemaphoreDemo();
            //sd.Run();


            new Thread(sayHello).Start("hello-1");
            new Thread(sayHello).Start("hello-2");
            new Thread(sayHello).Start("hello-3");
            Thread.Sleep(1000);
            handle.Set();
            handle.Reset();
            new Thread(sayHello).Start("hello-4");
            handle.Set();
            //Thread.Sleep(1000);
            //handle.Set();
            //Thread.Sleep(1000);
            //handle.Set();
            //Console.Read();


            

        }
    }
}
