﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Threading
{
    internal class ThreadDemo
    {

        public void Worker()
        {
            Thread t1 = new Thread(Infinite);
            for(int i=0;i<30;i++)
            {
                Console.WriteLine("Worker called");
                if (i == 5)
                {
                    t1.Start();
                    Console.WriteLine("infinite started");
                }
                if (i == 10)
                {
                    t1.Suspend();
                    Console.WriteLine("infinite paused");
                }                  
                if (i == 20)
                {
                    t1.Resume();
                    Console.WriteLine("infinite resumed");
                }                   
                if (i == 25)
                {
                    t1.Abort();
                    Console.WriteLine("infinite aborted");
                    Console.WriteLine("Worker aborted");
                    Thread.CurrentThread.Abort();
                }
                Thread.Sleep(1000);
            }
        }
        public void Infinite()
        {
            while (true)
            {
                Console.WriteLine("Infinite called");
                Thread.Sleep(1000);
            }

        }

    }
}
