﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Threading
{
    internal class ThreadPoolDemo
    {
        public void m1(object o)
        {
            for (int i = 0; i < 5; i++)
            {

                Console.WriteLine("m1 called "+o);
                Thread.Sleep(1000);
            }
        }
        public void m2(object o)
        {
            for (int i = 0; i < 5; i++)
            {

                Console.WriteLine("m2 called "+o);
                Thread.Sleep(1000);
            }
        }
    }
}
