﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Threading
{
    internal class MutexDemo
    {
        Mutex m=new Mutex(true,"hi");
        public void MyApp()
        {
            try
            {
                if (!m.WaitOne(5000))
                {
                    Console.WriteLine("This application is already running.");

                }
                else
                {
                    Console.WriteLine("Running the application.");

                }
            }
            catch 
            {
                m.ReleaseMutex();
            }
            
        }
    }
}
