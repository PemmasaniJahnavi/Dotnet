use Metageeks

--proc for get customer based on place
create proc sp_getcust 
as
select * from Customers where address='banglore'
--call
exec sp_getcust
--alter this with input parameter
alter proc sp_getcust (@m varchar(15))
as
select * from Customers where address=@m
--call
exec sp_getcust 'Hyderabad'


--declare variables
declare @a int
declare @b int
declare @c int
--assign value
set @a=5
set @b=10
set @c=@a+@b
print @c


--create proc for the addition
create proc sp_add(@a int,@b int)
as
declare @c int
set @c=@a+@b
print @c
--alter with format
alter proc sp_add(@a int,@b int)
as
declare @c int
set @c=@a+@b
print 'Sum of '+cast(@a as varchar)+' and '+cast(@b as varchar)+' is '+cast(@c as varchar)
--call
exec sp_add 10,12


--greatest of 2 numbers
create proc sp_great(@a int, @b int)
as
if(@a>@b)
print cast (@a as varchar)+' is greater'
else
print cast (@b as varchar)+' is greater'
--call
exec sp_great 25,66


--using loops
create proc sp_show
as
declare @a int
set @a=1
while(@a<=10)
begin
print @a
set @a=@a+1
end
--call
exec sp_show


--return value from proc
create proc add_proc(@a int,@b int)
as
declare @c int
set @c=@a+@b
return @c
--collect return value
declare @result int
exec @result=add_proc 10,25
print @result


--with output parameters
create proc addnums(@a int, @b int, @c int output,@d int output)
as
set @c=@a+@b
set @d=@a-@b
--fetch values
declare @x int, @y int
exec addnums 20,4,@x output,@y output
print 'The sum is '+cast(@x as varchar)
print 'The diff is '+cast(@y as varchar)


--handle error in proc
create proc numdivide(@a int, @b int)
as
declare @c int
set @c=@a/@b
print @c
--call
exec numdivide 10,1
--alter this with exception handling
alter proc numdivide(@a int, @b int)
as
begin try
declare @c int
set @c=@a/@b
print @c
end try
begin catch
print error_number()
print error_line()
print error_message()
end catch
--call
exec numdivide 10,0

--PRACTICE

--1. Create procedure which accepts 1 integer as parameter
--a. If user passess 1 display custid, customername , and age
--b. If user passes 2 display all records of customers
--c. Else print message invalid number 
create proc display(@z int)
as
if(@z=1)
select cid,custname,age from Customers
else if(@z=2)
select * from Customers
else
print 'Invalid'
--call
exec display 1
exec display 2
exec display 0


--2. Display Top N records from customers (Accept N Value as parameter)
create proc topval(@k int)
as
select top(@k)* from Customers
--call
exec topval 2
exec topval 3


--3. create a procedure to display customer and orders who make a purchase as 'books'
create proc display_cust
as
select * from customers c, orders o where o.product='Books' and c.cid in(select custid from orders )
--select * from customers c, orders o where c.cid=o.custid and o.product='Books' 
--call
exec display_cust


--4. Create a procedure for orders table , which displays all the purchase made between 1-12-2005 and 2-12-2007 (Accept date as parameter_)
create proc dis_purchase (@fd date, @td date)
as
select * from orders o where orderdate between @fd and @td
--call
exec dis_purchase '2025-1-1','2025-12-27'


--5. create a procedure which reads custid as parameter and return qty and produtid as output parameter
create proc dis_qty(@i int)
as
select qty,ordered from orders o where o.custid in(select cid from Customers)
--call
exec dis_qty 1


--6. Write a batch that will check for the existence of the productname �books� if it exists, display the total stock of the book else print �productname books not found�.
if exists(select custid from Orders where product='Books') 
select sum(qty) as Stock from Orders where product='Books'
else
print 'Product Name books not found'

--7. Create a procedure which accepts input parameter and inserts the data in the customer table.
create proc cust_insert(@cid int,@name varchar(15),@age int,@address varchar(20))
as
insert into customers values(@cid,@name,@age,@address)
--call
exec cust_insert 6,'Grishmi',20,'Mumbai'
--check updation
select * from customers


--8.insert a data to cutomer table via return value of sp_getdata()
--create getdata proc
create proc sp_getdata
as
select top 1* from Customers
--create insertion proc
alter proc Return_insert
as
insert into customers_demo (cid1,custname1,age1,address1) exec sp_getdata
--call
exec Return_insert
--check
select * from Customers_demo