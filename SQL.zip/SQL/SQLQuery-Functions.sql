use Metageeks

--create scalar function
create function myfunc(@a int)
returns int
begin
return @a*@a 
end
--run func
select dbo.myfunc(11)
select dbo.myfunc(age), custname from Customers


--create inline function
create function show(@b int)
returns table 
as
return (select * from Customers where cid=@b)
--run
select * from dbo.show(2)


--table valued functions
GO
CREATE FUNCTION fn_Employees
   (@length nvarchar(9))
RETURNS @tbl_Employees TABLE
   (EmployeeID int PRIMARY KEY NOT NULL,
   [Employee Name] Nvarchar(61) NOT NULL)
AS
BEGIN
   IF @length = 'ShortName'
      INSERT @tbl_Employees SELECT EmployeeID, LastName
      FROM Employees
   ELSE IF @length = 'LongName'
      INSERT @tbl_Employees SELECT EmployeeID,
      (FirstName + ' ' + LastName) FROM Employees
   RETURN
END


--PRACTICE

--1. create a function to find the greatest of three numbers
create function findmax(@x int, @y int, @z int)
returns int
as
BEGIN
declare @maxi int
   if(@x>@y and @x>@z)
     set @maxi= @x
   else if(@y>@z)
     set @maxi=@y
   else 
     set @maxi=@z
return @maxi
 END
--run
select dbo.findmax(12,6,19)


--2. create a function to calculate to discount of 10% on price on all the products
create function cal_discount(@x float)
returns float
as
begin
return (@x*0.1)
end
--Use function
select custid,dbo.cal_discount(price) from Orders



--3. create a function to calculate the discount on price as following if productname = 'books' then 10% if productname = toys then 15% else no discount
create function do_dis(@s varchar(10), @a float)
returns float
as
begin
declare @discount int
if (@s = 'Books')
set @discount=(@a*0.1) 
else if (@s='laptop')
set @discount=(@a*0.15)
else
set @discount=0
return @discount
end
--run
select dbo.do_dis('Books',1000)
select dbo.do_dis('laptop',1000)
select dbo.do_dis('Rings',1000)


--4. create inline function which accepts number and prints last n years of orders made from now.
create function num(@n int)
returns table
as
return (
select * from orders where OrderDate >= DATEADD(YEAR, -@n, GETDATE())
)
--run
select * from dbo.num(4)