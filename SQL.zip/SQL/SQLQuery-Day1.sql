create database Metageeks

use Metageeks

-- create
CREATE TABLE Customers (
  cid int primary KEY,
  custname varchar(15),
  age int,
  address varchar(20)
);

CREATE TABLE Orders (
  ordered int Primary KEY,
  custid int FOREIGN KEY references Customers(cid) on delete cascade,
  orderdate date,
  product varchar(10),
  price int,
  qty int
);


CREATE TABLE Customers_demo (
  cid1 int primary KEY,
  custname1 varchar(15),
  age1 int,
  address1 varchar(20)
);

create table Names(
nid int primary key,
cname varchar(10)
);

CREATE TABLE Customers_history (
  hcid int primary KEY,
  hcustname varchar(15),
  hage int,
  haddress varchar(20)
);

INSERT INTO Customers values (1,'Jahnavi',21,'Hyderabad'),(2,'Laasya',22,'Chennai'),(3, 'Vaishu',20, 'Pune'),(4,'HK',23,'Banglore'),(5,'Raj_Kumar',25,'Mumbai')
INSERT INTO Orders values (1,1,'2025-09-25','laptop',50000,1),(2,1,'2025-09-25','Bag',1000,2), (3,4,'2025-01-12','Books',1500,3),(4,2,'2025-03-17','Books',500,1)
INSERT INTO Customers values (8,'HK',23,'Banglore')

SELECT * FROM Customers
SELECT * FROM Orders

--get row which contains _ in name
select * from Customers where custname like '%[_]%'

--NESTED QUERIES 

--highest age
SELECT MAX(AGE) FROM CUSTOMERS WHERE AGE NOT IN (SELECT MAX(AGE) FROM CUSTOMERS) 


--all customers rows who purchased Books
select * from customers c where c.cid in(select custid from orders where Product='Books')


--all customers rows who purchased Books, laptop
select * from customers c where c.cid in (select custid from orders where Product='Books' or Product='Laptop')


--all orders where customer stays in Banglore
select * from orders o where o.custid in (select cid from Customers where address='banglore')


--who never purchased anything
select * from Customers c where c.cid not in (select custid from orders)


--lowest purchase in terms of quantity
select * from customers c where c.cid in (select custid from orders where qty in (select min(qty) from orders))


--display all whose age > Ajay , age not directly given
select * from customers c where c.age >(select age  from customers where custname='Jahnavi')


--list who ordered in 9 month
select * from customers c where c.cid in(select custid from orders where month(orderdate)=9)


--update id 1 age to 2
update customers set age=(select age from customers where cid=1) where cid=2
select * from customers


--before 16th of month addr not in banglore
--give cust details
select * from customers c where c.cid in(select custid from orders where day(orderdate)<16 and c.address not in (select address from orders where address='banglore'))
--give order details
select * from orders o where day(orderdate)<16 and o.custid not in (select cid from customers where address='banglore' )


--price greater than the average
select * from orders o where price >(select avg(price) from orders)


--increase price by 10% for cust from bang and bought Books
update orders set price=price*1.1 where product='books' and custid in(select cid from customers where address='banglore')
select * from orders


--customers from hyd and blr who purchased less than 3 products
select * from customers c where (address='banglore' or address='hyderabad') and c.cid in(select custid from orders where qty<3) 


--order details in format 
select Concat(ordered ,' ',orderdate)as 'OrderId-Date' ,price*qty as Total from Orders
--with crt format
select Concat(ordered ,' ',convert(varchar(10),orderdate,105))as 'OrderId-Date' ,price*qty as Total from Orders


--create view with totals, subtotals per customer and product
create view custview as select custid, product,sum(price) as total from orders group by rollup(custid,product)
select * from custview


--with all 3 create view
create view custview1 with encryption,schemabinding
as select custname from dbo.customers where address='Chennai' with check option
select * from custview1


--create view to any table which uses union operator
--can be done by using union on different tables also but same type is needed
create view custview2 
as select custid,orderdate from orders where qty<5 union select custid,orderdate from orders where qty>10 



--Common Table expression
select * from orders
select * from customers
--general statement for table, from this get max qty
select custid,sum(qty) from orders group by custid
--Usage of CTE
With Answer as (select custid,sum(qty) as Tqty from orders group by custid) 
select custid,Tqty from Answer where Tqty=(select max(tqty) from Answer)

