use Metageeks

--1. how to disable trigger 
ALTER TABLE custs DISABLE TRIGGER trg1

--2. how to enable trigger 
ALTER TABLE custs Enable TRIGGER trg1

--3. how disable all the triggers
ALTER TABLE custs DISABLE TRIGGER ALL 

--4. disable trigger for all the table in current database
Exec sp_msforeachtable "ALTER TABLE ? DISABLE TRIGGER all"


--5.  to set the order of trigger execution
EXEC sys.sp_settriggerorder @triggername = 'trig2',  
   @order = 'FIRST',  
   @stmttype = 'INSERT' 


 --PRACTICE

--trigger for delete
create trigger Trigger1
on Customers for delete
as
begin
if(@@rowcount>2)
begin
print 'U cannot delete more than 1 record at a time'
rollback transaction
end
end

delete from Customers where age>18
--alter trigger and check deleted table
alter trigger trigger1 on customers
for delete
as
begin
select * from deleted
end
--query
delete from Customers where age=23
select * from customers


--trigger for insert
create trigger Trigger2 on Customers
for insert
as
begin
if exists(select * from inserted where age<18)
begin
print 'Age cannot be less than 18'
rollback transaction
end
end
--query
insert into customers values (7,'HK',10,'Banglore')


--trigger on update
create trigger trigger3 on customers
for update
as
begin
select *from inserted
select * from deleted
end
--query
update customers set custname='Lassi' where cid=2


--instead of trigger
create trigger Trigger4 on Names 
instead of insert
as
begin
insert into Names select nid,upper(cname) from inserted
end
--query
insert into names values(2,'Vanaja')
--check
select * from names


--1. Create a trigger for table customer, which does not allow the user to delete the record who stays in Bangalore, delhi
create trigger Trigger6 on Customers 
for delete
as
begin
if exists(select * from deleted where (address='banglore' or address='Delhi'))
begin
print 'cannot delete records with address banglore or delhi'
rollback transaction
end
end
--query
delete from customers where cid=8
--or
create trigger Trigger6_1 on Customers 
for delete
as
begin
delete from customers where address in('banglore','Delhi')
rollback transaction
end


--2. Create a triggers for orders which allows the user to insert only books, cd, mobile
create trigger Trigger7 on Orders 
after insert 
as
begin
if exists(select 1 from inserted where product not in ('Books','Mobiles','cd'))
begin
print 'No other products allowed other than books, cd, mobiles'
rollback transaction
end
end
--or
create trigger Trigger71 on Orders
instead of insert
as
begin
insert into Orders select * from inserted where product in('Books','Mobiles','cd')
end
--query
insert into orders values(10,1,'2025-12-12','Dress',1670,1)


--3. Create a trigger for customer table whenever an item is delete from this table. The corresponding item should be added in customerhistory table.
create trigger Trigger8 on Customers
for delete
as
begin
insert into Customers_history select * from deleted 
end
--query
delete from customers where cid=2
select * from customers_history


--5. Do a trigger for joined view
--table A
create table a
(
custid int,
custname varchar(12)
)
--table B
create table b
(
custid int,
product varchar(12)
)
--View
create view testview
as
select a.* , b.product from a inner join b on a.custid =b.custid
--output of view
select * from testview
--trigger creation
create trigger Trigger9 on testview
instead of insert
as
begin
insert into a select custid,custname from inserted
insert into b select custid,product from inserted
end
--query
insert into testview values(1,'Varun Sai','Bike')
select * from a
select * from b
