--FINAL PRACTICE

--create database
Create Database EmployeesDB

--create tables
CREATE TABLE Manager (
    ManagerID varchar(5) PRIMARY KEY CHECK (ManagerID LIKE 'M[0-9][0-9][0-9]'),
    ManagerName VARCHAR(100) NOT NULL,
    JoiningDate DATE NOT NULL,
    Salary DECIMAL(10,2) NOT NULL CHECK (Salary>5000)
);

CREATE TABLE Dept (
    DepartmentID INT PRIMARY KEY IDENTITY(100,1),
    DepartmentName VARCHAR(100) NOT NULL CHECK (DepartmentName in('HR','Sales','Finance')),
    ManagerID varchar(5) NULL,
    FOREIGN KEY (ManagerID) REFERENCES Manager(ManagerID)
);


CREATE TABLE Employee (
    EmployeeID varchar(5) CHECK (EmployeeID LIKE 'E[0-9][0-9][0-9]'),
    EmployeeName VARCHAR(100) NOT NULL,
    JoiningDate DATE NOT NULL,
    ManagerID varchar(5) NULL,
    DepartmentID INT NULL,
    Salary DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (ManagerID) REFERENCES Manager(ManagerID),
    FOREIGN KEY (DepartmentID) REFERENCES Dept(DepartmentID)
);

--insert values
INSERT INTO Manager (ManagerID, ManagerName, JoiningDate, Salary)
VALUES
('M001','John Smith','2018-01-15',75000),
('M002','Sarah Lee','2019-03-10',65000),
('M003','Michael Brown','2020-07-25',70000);


INSERT INTO Dept (DepartmentName, ManagerID)
VALUES
('HR','M001'),
('Sales','M002'),
('Finance','M003');


INSERT INTO Employee (EmployeeID, EmployeeName, JoiningDate, ManagerID, DepartmentID, Salary)
VALUES
('E001','Alice Johnson','2021-04-10','M001',100,55000),
('E002','Bob Williams','2022-05-12','M002',101,60000),
('E003','Charlie Davis','2023-06-15','M003',102,58000),
('E004','Diana Miller','2023-08-01','M002',101,65000),
('E005','Ethan Wilson','2024-02-11','M001',100,62000);

--see tables
select * from Manager
select * from Dept
select * from Employee

--1. Display Emp Name, Salary , Joining date of all Employees
select EmployeeName,Salary,JoiningDate from Employee

--2. Display All Employee who have joined 1st of July 2000
select * from Employee where JoiningDate>'2000-07-01'
select * from Employee where JoiningDate='2000-07-01'

--3. Display All Employee Who�s salary is greater than 15000 and sort in descending order
select * from Employee where salary>15000 order by salary desc 

--4. Display All Employee Who works in Sales Department
select * from Dept where DepartmentName='sales'

--5. Display all employees who works for HR and Finance department who�s name starts with A
select * from Employee e where EmployeeName like 'A%' and e.DepartmentId in(select DepartmentID from Dept where DepartmentName in('HR','Finance'))

--6.Display All Employees who joining date is equal to managers joining date
select * from employee e join Manager m on m.ManagerID=e.ManagerId where m.JoiningDate=e.Joiningdate

--7. Display All Employee Who�s Manager Name is John Smith
select * from Employee where ManagerID in(select ManagerID from Manager where ManagerName='John Smith')

--8.Display All Manager Details who have joined 5 years back
select * from Manager where Year(JoiningDate)=year(Dateadd(Year,-5,getdate()))

--9.Display Total Employees who works for each dept., (display Deptid , TotalEmployee)
select DepartmentID, count(DepartmentID)as TotalEmployee from Employee group by DepartmentID

--10.display these if HR department EmpId EmpName JoiningDate DeptName ManagerName
select e.EmployeeId,e.EmployeeName,e.JoiningDate,d.DepartmentName,M.managerName from Manager m join Dept d on m.ManagerID=d.ManagerId join Employee e on e.DepartmentID=d.DepartmentID

--11.Create view with encryption to display only employee ID , EmpName ,Joining Date
create view Display_details with encryption
as
select EmployeeId,EmployeeName,JoiningDate from Employee
--see view
select * from Display_details

--12.Create procedure to display top N records who earns highest salary from Employee Table (Accept N from parameter)
create proc HSalary(@n int)
as
begin
select top (@n)* from Employee order by Salary desc
end
--run
exec HSalary 2

--13.Create a function which calculates Bonus of 15% of salary
create function Cal_Bonus(@s int)
returns int
as
begin
declare @bonus int
set @bonus=@s*0.15
return @bonus
end
--call function
select dbo.Cal_Bonus(Salary) from employee

--14.Create Trigger , whenever user insert a record display message as �Empid with E001 inserted successfully�
create trigger Display on Employee
after insert
as
begin
declare @id varchar(4)
select @id=EmployeeId from inserted
print 'Empid with '+@id+' inserted successfully' 
end
--check
insert into Employee values('E006','Raj Kumar','2024-03-15','M002',102,57000)
select * from Employee

--15.Increase employees by 15% who earns less than 15000
update Employee set salary=salary*1.15 where salary<15000
--salary less than 15k
insert into Employee values('E007','Hemanth','2023-05-04','M001',101,10000)
select * from Employee

--RegularExpression check
CREATE TABLE Manager1 (
    ManagerID varchar(10) PRIMARY KEY CHECK (Len(ManagerId)=10 and Left(managerId,1)='M' and Substring(ManagerID,2,10) NOT LIKE '%[^0-9]%'),--or use LIKE '{0-9}*10'
    ManagerName VARCHAR(100) NOT NULL,
    JoiningDate DATE NOT NULL,
    Salary DECIMAL(10,2) NOT NULL CHECK (Salary>5000)
);

--fails as constraint violated
INSERT INTO Manager1 (ManagerID, ManagerName, JoiningDate,Salary)
VALUES
('k111111111','Hemanth','2018-01-15',75000)
--row is inserted 
INSERT INTO Manager1 (ManagerID, ManagerName, JoiningDate,Salary)
VALUES
('M111111111','Hemanth','2018-01-15',75000)
--check table output
select * from manager1
