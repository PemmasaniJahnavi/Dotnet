use metageeks
select * from customers
select * from orders

insert into orders values (4,5,'2024-05-17','cd',70,2),(5,6,'2024-05-27','Mobiles',70000,1)

--1. Write a query to display the custid ,name, age, orderid,orderdate for product books or cd, sort data by name in descending order
select custid,custname,age,ordered,orderdate from Customers c join orders o on c.cid=o.custid where o.Product in('Books','cd','Mobile') order by custname desc


--2. Write a SQL statement to find the list of customers who live in the same city as ajay, and display custid , custname , price (price > 500)
select c.cid, c.custname, o.price, c.address from customers c join orders o on c.cid = o.custid join customers b on c.address = b.address where b.custname = 'Raj_Kumar' and price> 500 


--3. Write a query to find the name of customers along with order details who purchased 2 or more products
select c.custname,o.* from Customers c join Orders o on c.cid=o.custid where c.cid in(select custid from orders group by custid having count(product)>=2)

--4. A discount of 20% has been announced to all customers who resides in Hyderabad . display custid , custname , orderid and discount price
select o.custid,c.custname,o.ordered,o.price*0.2 as discount from Customers c join Orders o on c.cid=o.custid where c.address='Hyderabad'

--5. write a query to join three tables (create products table for the same)
--create table
create table Products ( pid int primary key, product varchar(15), price int)
select * from Products
insert into products values (1,'Laptop',70000),(2,'Books',500),(3,'cd',35),(4,'Mobile',25000)
--query
select * from Customers c join Orders o on c.cid=o.custid join Products p on o.product=p.product


--6. update price by 5% from orders table for customers who resides in pune and chennai
--to see discount
select o.custid,c.custname,o.price*0.5 as discount from customers c join orders o on c.cid=o.custid where c.address in('Pune','Chennai')
--to update discount
update o set o.price=o.price*0.5 from Orders o join Customers c on c.cid=o.custid where c.address in('Pune','Chennai')
select * from Orders

--7.Outer join
select * from Customers c full outer join orders o on c.cid=o.custid 

--8.create report as follows 1. Custname should be uppercase 2. Display only first 3 character of product 3. The report should be of September 2000
select o.custid,upper(c.custname) as Custname,substring(o.product,0,4) as Product,o.price,o.orderdate from Customers c join orders o on c.cid=o.custid where month(orderdate)=09 and year(orderdate)=2025