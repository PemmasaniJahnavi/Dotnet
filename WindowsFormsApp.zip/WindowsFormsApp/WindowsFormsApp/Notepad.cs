﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class Notepad : Form
    {
        public Notepad()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem15_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            richTextBox2.Font=fontDialog1.Font;
        }

        private void toolStripMenuItem14_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            richTextBox2.BackColor = colorDialog1.Color;
        }


        private void dateTimeToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = DateTime.Now.ToString();

        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            richTextBox2.Cut();
        }
        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            richTextBox2.Copy();
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            richTextBox2.Paste();
        }

        private void toolStripMenuItem11_Click(object sender, EventArgs e)
        {
            richTextBox2.Undo();
        }

        private void toolStripMenuItem12_Click(object sender, EventArgs e)
        {
            richTextBox2.Redo();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Rich Text Format (*.rtf)|*.rtf|Text Files(*.txt)|*.txt|All files(*.*)|*.*";

            //openFileDialog1.ShowDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox2.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.RichText);
            }          

        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Rich Text Format(*.rtf)|*.rtf|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            //saveFileDialog1.ShowDialog();

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {

                richTextBox2.SaveFile(saveFileDialog1.FileName, RichTextBoxStreamType.RichText);
            }
        }


    }
}
