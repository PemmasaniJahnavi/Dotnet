﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace WindowsFormsApp
{
    public partial class RegexDemo : Form
    {
        public RegexDemo()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (Regex.IsMatch(textBox1.Text, "^[a-zA-Z ]+$"))
                label1.Text = "Valid";
            else
                label1.Text = "Invalid";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Regex.IsMatch(textBox1.Text, "^[0-9]+$"))
                label1.Text = "Valid";
            else
                label1.Text = "Invalid";

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Regex.IsMatch(textBox1.Text, "^[a-zA-Z]{5}$"))
                label1.Text = "Valid";
            else
                label1.Text = "Invalid";

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Regex.IsMatch(textBox1.Text, "^[a-zA-Z]{3}[0-9]{4}$"))
                label1.Text = "Valid";
            else
                label1.Text = "Invalid";

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (Regex.IsMatch(textBox1.Text, "^[a-zA-Z_]+@[a-zA-Z]+.(com|in)$"))
                label1.Text = "Valid";
            else
                label1.Text = "Invalid";

        }

        private void button6_Click(object sender, EventArgs e)
        {

            if (Regex.IsMatch(textBox1.Text, "^www.[a-zA-Z_]+.(com|org|gov|in)$"))
                label1.Text = "Valid";
            else
                label1.Text = "Invalid";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Match m=Regex.Match(textBox1.Text, @"\d+");
            if (m.Success)
                label1.Text = m.Value;
            else
                label1.Text = "No such data found";
            
        } 

        private void button8_Click(object sender, EventArgs e)
        {
            MatchCollection m = Regex.Matches(textBox1.Text, @"\d+");
            if (m.Count>0)
            {
                foreach(var v in m)
                {
                    label1.Text += v ;
                }
            }
                
            else
                label1.Text = "No such data found";
        }


           
        private void button9_Click(object sender, EventArgs e)
        {
            MatchCollection m = Regex.Matches(textBox1.Text, @"\w+");
            if (m.Count > 0)
            {
                foreach (var v in m)
                {
                    label1.Text += v;
                }
            }
            else
            label1.Text = "No such data found";
            }

    }
}
