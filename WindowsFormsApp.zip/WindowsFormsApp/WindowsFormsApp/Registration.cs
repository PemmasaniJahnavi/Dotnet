﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string str = "";
            str = textBox1.Text;
            str += "\n";
            str += textBox2.Text;
            str += "\n";
            if (radioButton1.Checked)
                str += radioButton1.Text;
            else
                str += radioButton2.Text;
            str += "\n";
            str += dateTimePicker1.Text;
            str += "\n";
            str += comboBox1.Text;
            str += "\n";
            str += listBox1.Text;
            str += "\n";
            if (checkBox1.Checked)
                str += checkBox1.Text;
            str += " ";
            if(checkBox2.Checked)
                str += checkBox2.Text;
            str += "\n";
            if (checkBox3.Checked)
                str += checkBox3.Text;
            str += "\n";
            if (checkBox4.Checked)
                str += checkBox4.Text;
            str += "\n";

            label10.Text = str;
        }
    }
}
