﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        public int c = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            
            if (textBox1.Text == "Administrator" && textBox2.Text == "India*123")
            {
                MessageBox.Show("Log-in success.");
                c = 0;
            }
            else
            {
                textBox1.Text = "";
                textBox2.Text = "";
                c++;
                if (c >= 3)
                {
                    MessageBox.Show("Maximum attempts exceeded. Exiting.");
                    Environment.Exit(0);
                }
                else
                {
                    MessageBox.Show("Wrong Credentials,Try again.");
                }
            }
        }
    }
}
