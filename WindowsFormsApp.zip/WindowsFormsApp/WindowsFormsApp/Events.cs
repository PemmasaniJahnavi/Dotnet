﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class Events : Form
    {
        public Events()
        {
            InitializeComponent();
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            textBox2.Text = textBox1.Text;
        }

        private void Events_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Hi, load event called");
        }

        private void Events_DoubleClick(object sender, EventArgs e)
        {
            MessageBox.Show("The doubleclick event is triggered");
        }
    }
}
