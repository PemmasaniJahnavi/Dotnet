﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoDotnet
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //ConnectedDemo d = new ConnectedDemo();
            //d.Display();
            //d.Insert();
            //d.Delete();
            //d.ShowData();
            

            DisconnectedDemo dd=new DisconnectedDemo();
            dd.ShowData();
            //dd.AddRecord();
            //dd.Search();
            //dd.Delete();
            dd.SearchByName();
        }
    }
}
