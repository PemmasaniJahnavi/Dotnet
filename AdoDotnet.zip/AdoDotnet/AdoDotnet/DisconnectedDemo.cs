﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoDotnet
{
    internal class DisconnectedDemo
    {
        SqlConnection con = new SqlConnection("Integrated Security=true; server=WKSBAN36KELTR38\\SQLEXPRESS;Database=CompanyDB");
        SqlDataAdapter da;
        DataTable dt = new DataTable();
        public void ShowData()
        {

            da = new SqlDataAdapter("select * from Employees", con);
            SqlDataAdapter da1 = new SqlDataAdapter("select * from Departments", con);
            DataSet ds=new DataSet();

            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            SqlCommandBuilder cm=new SqlCommandBuilder(da);
            da.Fill(ds,"Emp");

            da1.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            da1.Fill(ds, "Dept");

            //Console.WriteLine(ds.Tables["Emp"].Rows[0][0]);//1st row 1st column
            //Console.WriteLine(ds.Tables["Emp"].Rows[0][1]);//1st row 2nd column
            //Console.WriteLine(ds.Tables["Emp"].Rows[0][3]);
            //Console.WriteLine(ds.Tables["Emp"].Rows[0][4]);
            //Console.WriteLine(ds.Tables["Emp"].Rows[0][5]);
            
            //assign table 1 to datatable
            dt = ds.Tables["Emp"];
            
            //print directly
            //Console.WriteLine(dt.Rows[0][0]);//1st row 1st column
            //Console.WriteLine(dt.Rows[0][1]);//1st row 2nd column
            //Console.WriteLine(dt.Rows[0][3]);
            //Console.WriteLine(dt.Rows[0][4]);
            //Console.WriteLine(dt.Rows[0][5]);

            //using for loop
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                Console.WriteLine(dt.Rows[i][0]);//1st row 1st column
                Console.WriteLine(dt.Rows[i][1]);//1st row 2nd column
                Console.WriteLine(dt.Rows[i][3]);
                Console.WriteLine(dt.Rows[i][4]);
                Console.WriteLine(dt.Rows[i][5]);
                Console.WriteLine("==================");
            }

        }

        public void Search()
        {
            Console.WriteLine("enter a id for search");
            int id=int.Parse(Console.ReadLine());
            DataRow dr=dt.Rows.Find(id);
            Console.WriteLine($"{dr[0]} {dr[1]} {dr[2]} {dr[3]}");

        }

        public void SearchByName()
        {
            Console.WriteLine("Search by other than primaykey");
            DataView dv=new DataView(dt);
            dv.RowFilter = "FirstName='Jahnavi'";
            //dv.RowFilter = "EmployeeId>2";
            //dv.RowFilter = "FirstName like 'J%'";
            foreach(DataRowView drv in dv)
            {
                Console.WriteLine($"{drv[0]} {drv[1]}");
            }

        }

        public void AddRecord()
        {
            dt.Rows.Add(13, "xyz", "abc", "Developer", 700000, "10-12-2025", 103);
            da.Update(dt);
            Console.WriteLine("record added successfully");

        }

        public void Delete()
        {
            Console.WriteLine("enter a id for delete");
            int id = int.Parse(Console.ReadLine());
            DataRow dr = dt.Rows.Find(id);
            dr.Delete();
            da.Update(dt);
            Console.WriteLine("Rows deleted successfully");

        }
    }
}
