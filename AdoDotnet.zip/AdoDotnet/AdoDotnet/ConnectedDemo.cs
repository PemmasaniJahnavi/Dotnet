﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AdoDotnet
{
    internal class ConnectedDemo
    {
        public void Display()
        {
            SqlConnection con = new SqlConnection("Integrated Security=true; server=WKSBAN36KELTR38\\SQLEXPRESS;Database=CompanyDB");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Employees", con);
            SqlDataReader result = cmd.ExecuteReader();
            //This read returns true if there is a record
            while (result.Read())
            {
                Console.WriteLine(result[0]);//this takes column index in table
            }
            con.Close();

        }
        public void Insert()
        {
            SqlConnection con = new SqlConnection("Integrated Security=true; server=WKSBAN36KELTR38\\SQLEXPRESS;Database=CompanyDB");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Departments values(110,'xyz')", con);
            int rows = cmd.ExecuteNonQuery();
            Console.WriteLine($"No of rows inserted {rows}");
            con.Close();

        }
        public void Delete()
        {
            SqlConnection con = new SqlConnection("Integrated Security=true; server=WKSBAN36KELTR38\\SQLEXPRESS;Database=CompanyDB");
            con.Open();
            Console.WriteLine("enter a id");
            int id = int.Parse(Console.ReadLine());
            SqlCommand cmd = new SqlCommand($"delete from Departments where DepartmentID={id}", con);
            int rows = cmd.ExecuteNonQuery();
            Console.WriteLine($"No of rows deleted {rows}");
            con.Close();

        }
        public void ShowData()
        {
            //reading 2 tables data, create 2 datareaders and use dr.close after every read from each table.
            SqlConnection con = new SqlConnection("Integrated Security=true; server=WKSBAN36KELTR38\\SQLEXPRESS;Database=CompanyDB");
            con.Open();

            //instead of query pass a procedure for making it loosely coupled
            SqlCommand cmd = new SqlCommand("select * from Employees;select * from Departments", con);

            SqlDataReader dr=cmd.ExecuteReader();
            Console.WriteLine("Table 1 data");
            while (dr.Read())
            {
                Console.WriteLine(dr[1]);
            }
            dr.NextResult();
            Console.WriteLine("=================");
            Console.WriteLine("Table 2 data");
            while(dr.Read())
            {
                Console.WriteLine(dr[1]);
            }
            con.Close();


        }

        public void ProcDisplay()
        {
            SqlConnection con = new SqlConnection("Integrated Security=true; server=WKSBAN36KELTR38\\SQLEXPRESS;Database=CompanyDB");
            con.Open();
            int id = int.Parse(Console.ReadLine());
            SqlCommand cmd = new SqlCommand($"myproc {id}", con);

            //To pass paramter to stored proc we can use sqlParameter use these
            //SqlParameter p1 = new SqlParameter("@a", id);
            //cmd.Parameters.Add(p1);
            //cmd.CommandType = System.Data.CommandType.StoredProcedure;
            //SqlDataReader dr = cmd.ExecuteReader();

            SqlDataReader result = cmd.ExecuteReader();
            //This read returns true if there is a record
            while (result.Read())
            {
                Console.WriteLine(result[1]);//this takes column index in table
            }
            con.Close();

        }
    }
}
