﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Serialization
{
    //Works only for public members.
    internal class XMLSerialization
    {
        public void convert_to_xml()
        {
            ArrayList ar = new ArrayList() { "India", "canada", "Russia" };

            XmlSerializer xr = new XmlSerializer(typeof(ArrayList));
            FileStream fs = new FileStream("C:\\Users\\pemmasani.jahnavi1\\Demo\\Serialization\\Countries.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            xr.Serialize(fs, ar);
            fs.Close();
            Console.WriteLine("Countries File serialized to XML");
            Console.WriteLine("=====================");
        }

        public void deserialize_from_xml()
        {
            ArrayList ar = new ArrayList();

            XmlSerializer xr = new XmlSerializer(typeof(ArrayList));
            FileStream fs = new FileStream("C:\\Users\\pemmasani.jahnavi1\\Demo\\Serialization\\Countries.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            ar = (ArrayList)xr.Deserialize(fs);
            foreach (var v in ar)
            {
                Console.WriteLine(v);
            }
            fs.Close();
            Console.WriteLine("Countries File deserialized from XML");
            Console.WriteLine("=====================");
        }

        public void Emp_to_xml()
        {
            Employees e = new Employees() { Empid = 100, Empname = "Jahnavi", Dept = "Testing", Salary = 80000 };

            XmlSerializer xr = new XmlSerializer(typeof(Employees));
            FileStream fs = new FileStream("C:\\Users\\pemmasani.jahnavi1\\Demo\\Serialization\\Employees.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            xr.Serialize(fs, e);
            fs.Close();
            Console.WriteLine("Emp File serialized to XML");
            Console.WriteLine("=====================");
        }

        public void Emp_from_xml()
        {
            Employees e = new Employees();
            XmlSerializer xr = new XmlSerializer(typeof(Employees));
            FileStream fs = new FileStream("C:\\Users\\pemmasani.jahnavi1\\Demo\\Serialization\\Employees.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            e = (Employees)xr.Deserialize(fs);
            Console.WriteLine($"{e.Empid} {e.Empname} {e.Dept} {e.Salary}");
            fs.Close();
            Console.WriteLine("Emp File deserialized from XML");
            Console.WriteLine("=====================");
        }
    }
}

