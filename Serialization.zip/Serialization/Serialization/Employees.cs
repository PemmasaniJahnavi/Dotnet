﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Serialization
{
    public class Employees
    {
        [XmlAttribute("empid")]
        public int Empid { get; set; }
        public string Empname { get; set; }

        [XmlElement("Department")]
        public string Dept { get; set; }
        [XmlIgnore]
        public int Salary { get; set; }

        public Employees() { }

    }
}
