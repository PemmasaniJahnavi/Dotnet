﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Serialization
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //XMLSerialization s =new XMLSerialization();
            //s.convert_to_xml();
            //s.deserialize_from_xml();
            //s.Emp_to_xml();
            //s.Emp_from_xml();

            //BinarySerialization b=new BinarySerialization();
            //b.SerializeBinary();
            //b.DeserializeBinary();

            JsonSerialization j = new JsonSerialization();
            //j.JSerialization();
            j.DSerialization();

        }
    }
}
