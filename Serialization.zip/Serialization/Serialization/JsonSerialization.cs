﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.IO;

namespace Serialization
{
    internal class JsonSerialization
    {
        public void JSerialization()
        {
            Ipl i = new Ipl() { TeamId = 100, TeamName = "SRH", Captain = "Pat", State = "Hyderabad" };
            string str=JsonSerializer.Serialize(i);
            File.WriteAllText("C:\\Users\\pemmasani.jahnavi1\\Demo\\Serialization\\Ipl1.json", str);
            Console.WriteLine("Json Serialization done");
        }

        public void DSerialization()
        {
            string j = File.ReadAllText("C:\\Users\\pemmasani.jahnavi1\\Demo\\Serialization\\Ipl1.json");
            Ipl i = JsonSerializer.Deserialize<Ipl>(j);
            Console.WriteLine(i.TeamId);
            Console.WriteLine(i.TeamName);
            Console.WriteLine(i.Captain);
            Console.WriteLine(i.State);
            Console.WriteLine("Json Deserialization completed");
        }
    }
}
