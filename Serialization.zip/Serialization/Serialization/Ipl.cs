﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Serialization
{
    [Serializable]
    internal class Ipl
    {
        public int TeamId { get; set; }
        public string TeamName { get; set; }
        public string State { get; set; }
        public string Captain { get; set; }
    }
}
