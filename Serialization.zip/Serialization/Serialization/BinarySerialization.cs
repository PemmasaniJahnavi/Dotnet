﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Serialization
{
    //this works for both public and private properties
    internal class BinarySerialization
    {
        public void SerializeBinary()
        {
            Ipl i = new Ipl() { TeamId = 100, TeamName = "RCB",Captain="Virat",State="Karnataka"};

            BinaryFormatter br = new BinaryFormatter();
            FileStream fs = new FileStream("C:\\Users\\pemmasani.jahnavi1\\Demo\\Serialization\\Ipl.bin", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            br.Serialize(fs, i);
            fs.Close();
            Console.WriteLine("Ipl File serialized to XML");
            Console.WriteLine("=====================");
        }

        public void DeserializeBinary()
        {
            Ipl i = new Ipl();
            BinaryFormatter br = new BinaryFormatter();
            FileStream fs = new FileStream("C:\\Users\\pemmasani.jahnavi1\\Demo\\Serialization\\Ipl.bin", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            i=(Ipl)br.Deserialize(fs);
            Console.WriteLine($"{i.TeamId} {i.TeamName} {i.State} {i.Captain}");
            fs.Close();
            Console.WriteLine("Ipl File serialized to XML");
            Console.WriteLine("=====================");
        }
    }
}
