﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoqDemo
{
    internal class Fake:IMath
    {
        public event EventHandler Myevent;

        //Write simplied logic for the real one
        public string Add(int x,int y)
        {
            return $"The sum is {x + y}";
        }
        public string Multiply(int x,int y)
        {
            return $"The product is {x * y}";
        }
        public int Data {  get; set; }
    }
}
