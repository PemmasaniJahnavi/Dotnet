﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyMathLib;

namespace MoqDemo
{
    internal class CodeCoverage
    {
        Class1 c = new Class1();
        [Test]
        public void m1()
        {
            var res = c.Add(15, 16);
            Assert.AreEqual(res,"The sum is 31");
        }

        [Test]
        public void m2()
        {
            var res = c.Multiply(10, 4);
            Assert.AreEqual(res, "The product is 40");
        }
    }
}
