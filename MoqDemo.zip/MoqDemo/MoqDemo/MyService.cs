﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoqDemo
{
    public interface IMath
    {
        string Add(int x, int y);
        string Multiply(int x,int y);
        public int Data { get; set; }

        public event EventHandler Myevent;
    }
    public class MyService:IMath
    {
        public event EventHandler Myevent;

        public virtual string Add(int x, int y)
        {
            return $"The sum is {x + y}";
        }
        public virtual string Multiply(int x,int y)
        {
            return $"The product is {x * y}";
        }
        public int Data { get; set; } = 100;

    }

}
