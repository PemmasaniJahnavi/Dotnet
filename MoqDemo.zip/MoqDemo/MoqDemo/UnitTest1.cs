using Moq;

namespace MoqDemo
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            MyService ms=new MyService();
            MyClient mc=new MyClient(ms);
            var res = mc.AddDisplay(10, 20);
            Assert.That(res,Is.EqualTo("The sum is 30"));
            //Assert.Pass();
        }


        [Test]
        public void StubTest()
        {
            Stub s=new Stub();
            MyClient mc = new MyClient(s);
            var res = mc.AddDisplay(10, 20);
            Assert.That(res, Is.EqualTo("The sum is 30"));
            //Assert.Pass();
        }

        [Test]
        public void FakeTest()
        {
            Fake f = new Fake();
            MyClient mc = new MyClient(f);
            var res = mc.AddDisplay(50, 20);
            Assert.That(res, Is.EqualTo("The sum is 70"));
            //Assert.Pass();
        }

        [Test]
        public void MoqTest()
        {
            var ob = new Mock<IMath>();
            ob.Setup(t => t.Add(10, 20)).Returns("The sum is 30");
            MyClient mc= new MyClient(ob.Object);
            var res=mc.AddDisplay(10,20);
            Assert.That(res, Is.EqualTo("The sum is 30"));
        }

        [Test]
        public void MoqTest1()
        {
            //using readymade Moq with fake
            var ob = new Mock<IMath>();
            ob.Setup(t => t.Add(It.IsAny<int>(), It.IsAny<int>())).Returns((int a, int b) =>$"The sum is {a + b }");
            MyClient mc = new MyClient(ob.Object);
            var res = mc.AddDisplay(10, 20);
            Assert.That(res,Is.EqualTo("The sum is 30"));
        }

        
        [Test]
        public void MoqTest2()
        {
            //Throwing exception using Moq
            var ob = new Mock<IMath>();
            ob.Setup(t => t.Add(It.Is<int>(s=>s>15), It.IsAny<int>())).Throws<ArgumentException>();
            MyClient mc = new MyClient(ob.Object);
            Assert.Throws<ArgumentException>(()=> mc.AddDisplay(16, 20));
        }

        [Test]
        public void MoqTest3()
        {
            //using verify, it always comes at the last
            var ob = new Mock<IMath>();
            ob.Setup(t => t.Add(It.IsAny<int>(), It.IsAny<int>())).Returns((int a, int b) => $"The sum is {a + b}");
            MyClient mc = new MyClient(ob.Object);
            var res=mc.AddDisplay(15, 25);
            Assert.That(res, Is.EqualTo("The sum is 40"));
            ob.Verify(c=>c.Add(15,25),Times.Once());

        }

        [Test]
        public void Moqtest4()
        {
            var ob=new Mock<IMath>(MockBehavior.Strict);
            ob.Setup(c => c.Add(15, 25)).Returns("The sum is 40");
            ob.Setup(c => c.Multiply(10, 5)).Returns("The product is 50");
            MyClient mc=new MyClient(ob.Object);
            var res= mc.AddDisplay(15, 25);
            var res1=mc.MulDisplay(10, 5);
            Assert.That(res, Is.EqualTo("The sum is 40"));
            Assert.That(res1, Is.EqualTo("The product is 50"));

        }

        [Test]
        public void Moqtest5()
        {
            var ob = new Mock<IMath>(MockBehavior.Loose);          
            ob.Setup(c => c.Multiply(10, 5)).Callback<int,int>
                ((a,b)=>Console.WriteLine($"Method executed successfuly for {a} {b}")).
                Returns("The product is 50");
            MyClient mc = new MyClient(ob.Object);          
            var res = mc.MulDisplay(10, 5);          
            Assert.That(res, Is.EqualTo("The product is 50"));

        }

        [Test]
        public void PropTest()
        {
            var ob = new Mock<IMath>();
            ob.SetupProperty(c => c.Data, 100);
            MyClient mc = new MyClient(ob.Object);
            //ob.SetupGet(c => c.Data);
            Assert.AreEqual(100,ob.Object.Data);
        }

        [Test]
        public void CallbaseTest()
        {
            var ob = new Mock<MyService>();
            ob.CallBase = true;
            ob.Setup(t => t.Add(10, 20)).Returns("The sum is 30");//stub
            MyClient mc = new MyClient(ob.Object);
            
            var res = mc.AddDisplay(10, 20);
            var res1=mc.MulDisplay(10, 20);
            //this calls fake method as we wrote setup for this ie behaviour given
            Assert.That(res, Is.EqualTo("The sum is 30"));
            //this calls real method as no setup written, CallBase is true
            Assert.That(res1, Is.EqualTo("The product is 200"));
        }

        [Test]
        public void EventTest()
        {
            var ob = new Mock<IMath>();
            bool wasCalled = false;

            //code to register the event
            ob.Object.Myevent += (s, e) => wasCalled = true;

            //code to call the event
            ob.Raise(m => m.Myevent += null, EventArgs.Empty);
            Assert.IsTrue(wasCalled);


        }
    }
}
