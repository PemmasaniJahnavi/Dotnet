﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssignMyProduct;
using Moq;

namespace MoqDemo
{
    internal class Assignment
    {
        [Test]
        public void Product()
        {
            var ob = new Mock<IProductRepository>();
            ob.Setup(t => t.GetProductById(1)).Returns(new Product { Id = 1, Name = "Laptop" });
            ProductService ps=new ProductService(ob.Object);
            var res = ps.GetProductName(1);
            Assert.AreEqual(res,"Laptop");
        }

        [Test]
        public void Product1()
        {
            var ob = new Mock<IProductRepository>();
            ob.Setup(t => t.GetProductById(1)).Returns(new Product { Id = 5, Name = "Unknown" });
            ProductService ps = new ProductService(ob.Object);
            var res = ps.GetProductName(5);
            Assert.AreEqual(res, "Unknown");
        }

        [Test]
        public void Scenario2()
        {
            var ob = new Mock<IProductRepository>();
            ob.Setup(t => t.GetProductById(1)).Returns(new Product { Id = 1, Name = "Laptop" });
            ProductService ps = new ProductService(ob.Object);
            var res = ps.GetProductName(1);
            Assert.AreEqual(res, "Laptop");
            ob.Verify(c => c.GetProductById(1), Times.Once());
        }

        [Test]
        public void Scenario21()
        {
            var ob = new Mock<IProductRepository>();
            ob.Setup(t => t.GetProductById(2)).Returns(new Product { Id = 3, Name = "Unknown" });
            ProductService ps = new ProductService(ob.Object);
            var res = ps.GetProductName(3);
            Assert.AreEqual(res, "Unknown");
            ob.Verify(c => c.GetProductById(2), Times.Never());
        }

        [Test]
        public void Scenario3()
        {
            var ob = new Mock<IProductRepository>();
            ob.Setup(t => t.GetProductById(It.Is<int>(s => s == 0))).Throws<InvalidOperationException>();
            ProductService ps = new ProductService(ob.Object);
            var res=Assert.Throws<InvalidOperationException>(() => ps.GetProductName(0));
            Assert.AreEqual(res.Message,"0 called");

        }

        [Test]
        public void Scenario4()
        {
            var ob = new Mock<IProductRepository>();
            ob.Setup(t => t.GetAllProducts()).Returns(new List<Product>()
            {
                new Product {Name="Laptop" },
                new Product{Name="Phone"},
                new Product{Name="Tablet"} }
                );
            ProductService ps = new ProductService(ob.Object);
            var res = ps.GetAllProducts();
            Assert.AreEqual(3, res.Count);
            Assert.AreEqual(res[0].Name, "Laptop");
            Assert.AreEqual(res[1].Name, "Phone");
            Assert.AreEqual(res[2].Name, "Tablet");
            ob.Verify(t => t.GetAllProducts(),Times.Once());
            Assert.IsTrue(res.Any(t => t.Name.Contains("Phone")));

        }


        [Test]
        public void Scenario5()
        {
            var ob = new Mock<IProductRepository>();
            ob.Setup(t => t.GetProductById(1)).Returns(new Product { Name = "Laptop" });
            ob.Setup(t => t.GetProductById(2)).Returns(new Product { Name = "Phone" });
            ob.Setup(t => t.GetProductById(It.Is<int>(t=>t!=1&&t!=2))).Callback<int>((a)=> Console.WriteLine($"Method executed successfuly for {a}")).
                Returns(new Product { Name="Null"});    
            ProductService ps = new ProductService(ob.Object);
            var r1 = ps.GetProductName(1);
            var r2 = ps.GetProductName(2);
            var r3 = ps.GetProductName(3);
            Assert.AreEqual(r1, "Laptop");
            Assert.AreEqual(r2, "Phone");
            Assert.AreEqual(r3, "Null");

        }

        [Test]
        public void Scenario6()
        {
            var ob = new Mock<IPaymentService>();
            ob.Setup(t => t.GetBalance()).Returns(500);
            ob.Setup(t => t.ProcessPayment(It.Is<decimal>(t => t < 1000))).Returns(true);
            ob.Setup(t => t.ProcessPayment(It.Is<decimal>(t => t > 1000))).Returns(false);
            var res = ob.Object.GetBalance();
            var res1 = ob.Object.ProcessPayment(1020);
            var res2 = ob.Object.ProcessPayment(700);
            Assert.AreEqual(res,500);
            Assert.AreEqual(res1, false);
            Assert.AreEqual(res2, true);
        }

        [Test]
        public void Scenario7()
        {
            var ob = new Mock<IProductRepository>();
            ob.Setup(t => t.GetProductByIdAsync(1)).ReturnsAsync(new Product{Name = "Laptop" });
            ProductService ps = new ProductService(ob.Object);
            var r1= ps.GetProductByIdAsync(1);
            Assert.AreEqual("Laptop",r1.Result);

        }



    }
}
