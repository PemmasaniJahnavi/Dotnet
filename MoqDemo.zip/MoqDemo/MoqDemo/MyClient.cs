﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoqDemo
{
    internal class MyClient
    {
        IMath obj;
        public MyClient(IMath m) 
        {
            obj = m;
        }
        public string AddDisplay(int x,int y)
        {
            return obj.Add(x, y);
        }
        public string MulDisplay(int x,int y)
        {
            return obj.Multiply(x,y);   
        }
    }
}
