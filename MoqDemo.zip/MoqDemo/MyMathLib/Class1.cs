﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyMathLib
{
    public interface IMath1
    {
        string Add(int x, int y);
        string Multiply(int x, int y);
        int Data { get; set; }

        event EventHandler Myevent;
    }
    public class Class1:IMath1
    {
            public event EventHandler Myevent;

            public virtual string Add(int x, int y)
            {
                return $"The sum is {x + y}";
            }
            public virtual string Multiply(int x, int y)
            {
                return $"The product is {x * y}";
            }
            public int Data { get; set; } = 100;

          }
    }
