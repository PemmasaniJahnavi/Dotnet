﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyMathLib
{
    public interface IMath2
    {
        string Sub(int x, int y);
        string Divide(int x, int y);
        int Data { get; set; }

        event EventHandler Myevent;
    }

    internal class Class2:IMath2
    {
        public event EventHandler Myevent;
        public int Data { get; set; }

        public virtual string Sub(int x, int y)
        {
            return $"The diff is {x - y}";
        }
        public virtual string Divide(int x, int y)
        {
            return $"The quotient is {x/y}";
        }

    }
}
