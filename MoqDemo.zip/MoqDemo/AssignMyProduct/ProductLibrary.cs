﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignMyProduct
{
    public interface IProductRepository
    {
        Product GetProductById(int id);
        List<Product> GetAllProducts();
        Task<Product> GetProductByIdAsync(int id);
    }

    public interface IPaymentService
    {
        bool ProcessPayment(decimal amount);
        decimal GetBalance();
    }

    public class ProductService
    {
        private readonly IProductRepository _repository;
        private readonly IPaymentService _paymentService;
        public ProductService(IProductRepository repository)
        {
            _repository = repository;
            
        }
        public ProductService(IPaymentService payment)
        {
            _paymentService = payment;

        }

        public string GetProductName(int id)
        {
            try
            {
                var product = _repository.GetProductById(id);
                return product?.Name ?? "Unknown";
            }
            catch(Exception e)
            {
                throw new InvalidOperationException("0 called");
            }

        }
        public List<Product> GetAllProducts()
        {
            return _repository.GetAllProducts();
        }

        public async Task<String> GetProductByIdAsync(int id)
        {
            try
            {
                var product = await  _repository.GetProductByIdAsync(id);
                return product?.Name ?? "Unknown";
            }
            catch (Exception e)
            {
                throw new InvalidOperationException("Its error");
            }

        }

    }
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
