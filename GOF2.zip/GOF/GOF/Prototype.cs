﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOF
{
    //always creating an object is expensive so we clone using this pattern.
    //returning copy of object not the original one (issue of reference type modification not seen here)

    //create a class and a method Clone that returns obj of current class, returns copy of obj using this.MemberwiseClone();
    
    internal class Prototype
    {
       
        public string MName { get; set; }
        public int Price { get; set; }
        public string Company { get; set; }

        public object Clone()
        {
            //this does shallow copy
            return this.MemberwiseClone();
        }
    }
}
