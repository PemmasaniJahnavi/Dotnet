﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOF
{
    //Mark class sealed- restrict inheritance.
    //Create private constructor- block new keyword usage.
    //Create static method that returns instance of Singleton class (logic to restrict to 1 obj) or create property.
    //To check use GetHashCode Method in Main.
    internal sealed class SingletonDemo
    {
        static SingletonDemo  obj;
        private SingletonDemo() 
        {
        }
        public static SingletonDemo GetInstance()
        {
            if(obj==null)
            {
                obj = new SingletonDemo();
            }
            return obj;
        }

        public static SingletonDemo GetInstanceProp
        {
            get
            {
                if (obj == null)
                {
                    obj = new SingletonDemo();
                }
                return obj;

            }
            
        }
        public void DbMethod()
        {
            Console.WriteLine("The DB method called");
        }
    }
}
