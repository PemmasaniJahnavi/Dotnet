﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Net.NetworkInformation;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Arrays
{
    internal class Program
    {

//1. Create a function to find common value from two arrays
//a.Int[] TeamA = { 45, 78, 45, 34, 65, 89 };
//b.Int[] TeamB = { 78, 4, 8, 9, 65, 3, 7, 34 };
        public void Common()
        {
            int[] TeamA = { 45, 78, 45, 34, 65, 89 };
            int[] TeamB = { 78, 4, 8, 9, 65, 3, 7, 34 };
            foreach(int i in TeamA)
            {
                foreach(int j in TeamB)
                {
                    if (i==j)
                            Console.WriteLine(i);
                }
            }
        }

//2. write a logic to print only even numbers from given array
//int[] a = { 10, 11, 12, 13, 14, 15, 16 };
        public void PrintArray()
        {
            int[] a = { 10, 11, 12, 13, 14, 15, 16 };
            foreach(int i in a)
            {
                if(i%2==0)
                    Console.WriteLine(i);
            }

        }

//3. Write a logic to print all value in upper case
//string[] s = { "india", "canada", "uk", "us" };
        public void UString()
        {
            string[] s = { "india", "canada", "uk", "us" };
            foreach(string i  in s)
            {
                Console.WriteLine(i.ToUpper());
            }

        }

//4. write a logic to print all value containing character 'a' from given array
//string[] s = { "india", "canada", "uk", "us" };
        public void ContainA()
        {
            string[] s = { "india", "canada", "uk", "us" };
            foreach(string i in s)
            {
                if(i.Contains('a'))
                    Console.WriteLine(i);
            }

        }

//5. Create 3*3 multi dimension array and find the sum of 1st column
        public void MdArray()
        {
            int[,] a = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
            int n = 0;
           for(int i=0;i<3;i++)
            {
                n = n + a[i,0];
            }
            Console.WriteLine(n);
        }

//6. Create a function by name GetData with following logic
//Object[] myObjects = new Object[5];
//myObjects[0] = "hello";
//myObjects[1] = 123;
//myObjects[2] = 123.4;
//myObjects[3] = null;
//myObjects[4]=”CGI”
//Using is Expression find out the string form from this array and print the value it contains
        public void GetData()
        {
            Object[] myObjects = new Object[5];
            myObjects[0] = "hello";
            myObjects[1] = 123;
            myObjects[2] = 123.4;
            myObjects[3] = null;
            myObjects[4] = "CGI";

            foreach(var v in myObjects)
            {
                if (v is  string)
                    Console.WriteLine(v);
            }

        }

//7.String[] st = {“Srilanka”,”Singapore”,”India”,”Swedan”,”Canada”};
//Develop a code to print all country names starting with S and greater than 7
//characters long. Print the output in uppercase
        public void Country()
        {
            String[] st = {"Srilanka","Singapore","India","Swedan","Canada"};
            foreach(var v in st)
            {
                if(v.Length>7 && v.StartsWith("S"))
                    Console.WriteLine(v);
            }

        }

        static void Main(string[] args)
        {
            Program p = new Program();
            p.Common();
            p.PrintArray();
            p.UString();
            p.ContainA();
            p.MdArray();
            p.Country();

        }
    }
}
