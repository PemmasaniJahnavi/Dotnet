﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace OOPS1
{
//1. Create class BaseCls with a constructor having int parameter and prints the same using console.writeline
//Create class DerivedCls with constructor having int parameter and prints the number using console.writeline
//From main create instance of only derived class and print the output of both constructors(hint use inheritance and base keyword)
    public class BaseCls
    {
        public BaseCls(int a)
        {
            Console.WriteLine(a);
        }
    }
    public class DerivedCls:BaseCls
    {
        public DerivedCls(int a):base(a)
        {
            Console.WriteLine(a);
        }

    }


//2. Polymorphism ▪ Create an abstract class Shape with an abstract method CalculateArea().
//▪ Implement concrete classes like Circle, Rectangle, and Triangle.
    public abstract class Shape
    {
        public abstract void  CalculateArea();
       
    }
    public class Circle : Shape
    {
        public float r { get; set; }
        public float Area { get; set; }
        public override void CalculateArea()
        {
            Console.WriteLine("Enter the radius of circle:");
            r = float.Parse(Console.ReadLine());
            Area=(float)(3.14*Math.Pow(r,2));
            Console.WriteLine($"The area of circle is {Area}");
        }
    }

    public class Square : Shape
    {
        public int side { get; set; }
        public override void CalculateArea()
        {
            Console.WriteLine("Enter the side of a square");
            side= int.Parse(Console.ReadLine());
            Console.WriteLine($"The area of square is {side*side}");
        }
    }

    public class Triangle:Shape
    {
        public int b { get; set; }
        public int h { get; set; }
        public override void CalculateArea()
        {
            Console.WriteLine("Enter the base and height");
            b= int.Parse(Console.ReadLine());
            h = int.Parse(Console.ReadLine());
            Console.WriteLine($"The area of triangle is {0.5*b*h}");
        }

    }
//3. Scenario case vehicle rental system--all concepts

    public abstract class Vehicle
    {
        public string Vname { get; set; }
        public int DayRent { get; set; }
        public string FuelType { get; set; }
        public Vehicle()
        {
            Vname = "Mahindra XUV"; DayRent = 2500; FuelType = "Diesel";

        }
        public Vehicle(string vname, int dayrent, string fueltype)
        {
            Vname = vname;
            DayRent = dayrent;
            FuelType = fueltype;
        }

        public abstract void DisplayDetails();
    }

    public class Bike : Vehicle
    {
        public bool HasHelmet { get; set; }
        public Bike(bool b)
        {
         HasHelmet = b;   
        }
        public Bike(string vname, int dayrent, string fueltype,bool b):base(vname,dayrent,fueltype)
        {
            HasHelmet = b;
        }
        public override void DisplayDetails()
        {
            Console.WriteLine("The Bike Details are:");
            Console.WriteLine($"Name={Vname}\n Day Rent={DayRent}\n FuelType is {FuelType}\n Has Helmet={HasHelmet}");
        }
    }

    public class Truck : Vehicle
    {
        public int LoadCapacity { get; set; }
        public Truck(int l)
        {
            LoadCapacity = l;
        }
        public Truck(string vname, int dayrent, string fueltype, int l) : base(vname, dayrent, fueltype)
        {
            LoadCapacity = l;
        }
        public override void DisplayDetails()
        {
            Console.WriteLine("The Truck Details are:");
            Console.WriteLine($"Name={Vname}\n Day Rent={DayRent}\n FuelType is {FuelType}\n Load Capacity={LoadCapacity}");
        }
    }

    public class Car : Vehicle
    {
        public int Seats { get; set; }
        public Car(int s)
        {
            Seats = s;
        }
        public Car(string vname, int dayrent, string fueltype, int s) : base(vname, dayrent, fueltype)
        {
            Seats = s;
        }
        public override void DisplayDetails()
        {
            Console.WriteLine("The Truck Details are:");
            Console.WriteLine($"Name={Vname}\n Day Rent={DayRent}\n FuelType is {FuelType}\n Load Capacity={Seats}");
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Vehicle v = new Car("Benz", 10000, "Diesel", 4);
            v.DisplayDetails();
            v = new Bike(true);
            v.DisplayDetails();
            v = new Truck("xyz", 5000, "Petrol", 500);
            v.DisplayDetails();


        }
    }
}
