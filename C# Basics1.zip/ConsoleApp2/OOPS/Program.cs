﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace OOPS
{
    
//1. Create Empclass, from Main Create an object of EmpClass , initialize properties and call above methods
    public class EmpClass
    {
        public int EmpId { get; set; }
        public double Salary { get; set; }
        public string Dept { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public void displayFullName()
        {
            Console.WriteLine("Enter FirstName");
            FirstName = Console.ReadLine();
            Console.WriteLine("Enter LastName");
            LastName = Console.ReadLine();
            Console.WriteLine(FirstName+" "+LastName);
        }

        public void CalculateAnnualSalary()
        {
            Console.WriteLine("Enter the Monthly Salary");
            Salary = Double.Parse(Console.ReadLine());
            double Total_Salary = Salary * 12;
            Console.WriteLine(Total_Salary);

        }
    }

//2. Create Student class with following properties Studentid,StudentName,Marks(out of 800)
//a.Create GetDetails() Method to print id, name and marks with first class , second class or fail
//b.Create an instance of student class from main method >60 First<60 > 50 Second< 50 Fail
    public class Students
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public double Marks { get; set; }

        public void GetDetails()
        {
            Console.WriteLine("Enter the Student Details in order 1.Id 2.Name 3.Marks(for 800)");
            StudentId = int.Parse(Console.ReadLine());
            StudentName = Console.ReadLine();
            Marks=int.Parse(Console.ReadLine());
            Console.WriteLine($"Id={StudentId} Name={StudentName}");
            double Percent = (Marks/800)*100;
            if (Percent > 60)
                Console.WriteLine("First Class");
            else if (Percent > 50 && Percent < 60)
                Console.WriteLine("Second Class");
            else if(Percent <50)
                Console.WriteLine("Fail");

        }

    }

//3. Create class Students with following Details to store up to 5 students data (make Students class as an array from main)
//a.Studentid
//b.StudentName
//c.Marks (4 Different Marks out of 100)
//A.DisplayDetails() Method to print id , name and marks with first class ,second class or fail
//B.Create a Method GetById to Lists student by ID
//C.Create a Method GetFirstClassDet to List all the students with first class
//D. Create a Method GetByChar to list all the student name which starts with S
//Create an instance of students class from main method
    public class Students1
    {
        public string StudentName { get; set; }
        public int StudentId { get; set; }
        public double[] Marks { get; set; } = new double[4];
        public double Percent { get; set; }
        public double n { get; set; }
        public void GetDetails()
        {
            Console.WriteLine("Enter the Student Details in order 1.Id 2.Name");
            StudentId = int.Parse(Console.ReadLine());
            StudentName = Console.ReadLine();
            Console.WriteLine("Enter 4 subject marks (out of 100)");
            for(int i=0;i<4;i++)
            {
                Marks[i]=double.Parse(Console.ReadLine());
                n = n + Marks[i];
            }               

        }
        public double Percentage()
        {
            Percent = (n / 400) * 100;
            return Percent;
        }

        public void SClass()
        {
            if (Percent > 60)
                Console.WriteLine("First Class");
            else if (Percent > 50 && Percent < 60)
                Console.WriteLine("Second Class");
            else if (Percent < 50)
                Console.WriteLine("Fail");
        }
        public void DisplayDetails()
        {
            Console.WriteLine(StudentId);
            Console.WriteLine(StudentName);        
            double p=Percentage();
            Console.WriteLine($"The percentage is {p}");
            SClass();
        }
    }

    internal class Program
    {
        public static void GetById(Students1[] s, int id)
        {
            foreach (var v in s)
            {
                if (v.StudentId == id)
                    v.DisplayDetails();
            }

        }
        public static void GetByFirstClass(Students1[] s)
        {
            foreach (var v in s)
            {
                if (v.Percentage() > 60)
                    Console.WriteLine($"{v.StudentId} {v.StudentName}");
            }
        }

        public static void GetSNames(Students1[] s)
        {
            foreach (var v in s)
            {
                if (v.StudentName.ToUpper().StartsWith("S"))
                    Console.WriteLine(v.StudentName);
            }
        }
        static void Main(string[] args)
        {
            EmpClass e = new EmpClass();
            e.displayFullName();
            e.CalculateAnnualSalary();
            Students s = new Students();
            s.GetDetails();
            Students1[] s1=new Students1[5];
            for (int i = 0; i<5;i++)
            {
                s1[i]=new Students1();
                s1[i].GetDetails();
            }
            foreach(var v in s1)
            {
                v.DisplayDetails();
            }
            GetById(s1, 101);
            GetByFirstClass(s1);
            GetSNames(s1);
        }
    }
}
