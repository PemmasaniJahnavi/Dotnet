﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace ConsoleApp2
{
    internal class Program
    {
        public void Greatest()
        {
            Console.WriteLine("Enter num1");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter num2");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter num3");
            int c = Convert.ToInt32(Console.ReadLine());
            if (a > b && a > c)
                Console.WriteLine($"{a} is greatest");
            else if (b > c)
                Console.WriteLine($"{b} is greatest");
            else
                Console.WriteLine($"{c} is greatest");
        }

        public void FindMax()
        {
            Console.WriteLine("Enter num1");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter num2");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter num3");
            int c = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(Math.Max(a, Math.Max(b, c)));
        }


        //Accept empname, basic salary from the user and calculate the following
        //a.HRA 15% of basic salary
        //b.DA 10% of basic salary
        //c. TAX 8% of gross
        //d.GROSSPAY = BASIC + DA + HRA

        public void Employee()
        {
            Console.WriteLine("Enter EmployeeName");
            String name = Console.ReadLine();
            Console.WriteLine("Enter Salary");
            double s = Convert.ToDouble(Console.ReadLine());
            double HRA = s * 0.15;
            double DA = s * 0.1;
            double Gross = s + HRA + DA;
            double Tax = Gross * 0.08;
            Console.WriteLine($"HRA is {HRA}");
            Console.WriteLine($"DA is {DA}");
            Console.WriteLine($"Gross is {Gross}");
            Console.WriteLine($" Tax to be paid is {Tax}");
        }

        //Create a function by name “Factorial”
        //a.Develop a code to find the factorial of a number
        //b.If the user does not enter any value, find factorial of 5 by default
        public int Factorial(int n = 5)
        {
            int sum = 1;
            for (int i = 1; i <= n; i++)
                sum = sum * i;
            return sum;
        }

        public void Fact()
        {
            String s = Console.ReadLine();
            int n;
            int sum = 1;
            if (string.IsNullOrEmpty(s))
                n = 5;
            else
                n = int.Parse(s);

            for (int i = 1; i <= n; i++)
                sum = sum * i;
            Console.WriteLine($"The Factorial is {sum}");

        }

        //4. Create a function by name “Sumof10Nums”
        //a.Develop a code to find the sum of 10 numbers, the loop has to break
        //immediately if the user enters negative value.Display appropriate message
        //after breaking the loop.

        public void Sum10Nums()
        {
            Console.WriteLine("Enter 10 numbers");
            int sum = 0;
            int n;
            for (int i = 0; i < 10; i++)
            {
                if (Convert.ToInt32(Console.ReadLine()) < 0)
                {
                    Console.WriteLine("Negative values not allowed");
                    break;
                }
                else
                    n = Convert.ToInt32(Console.ReadLine());
                sum = sum + n;
            }
            Console.WriteLine($"The sum is {sum}");

        }

        // 5. Create a function by name Swapnums
        //a.Develop a code to swap two numbers
        //b.Develop a code to swap two numbers without using temporary variable

        public void Swap()
        {
            Console.WriteLine("Enter a and b values for swap:");
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            a = a + b;
            b = a - b;
            a = a - b;
            Console.WriteLine($"After swap a={a} and b={b}");

        }

        //6. Create a function by name copystring.Accept two strings from the user ,
        //copy both the strings into the new string and print new string in output
        //window
        public void CopyString()
        {
            Console.WriteLine("Enter a String value:");
            String s1 = Console.ReadLine();
            String s2 = Console.ReadLine();
            string s3 = s1 + s2;
            Console.WriteLine(s3);
        }

        //7. Create a function by name divnums.Write a program to display the
        //reminder and quotient after dividing the first number by second.

        public void Divnums()
        {
            Console.WriteLine("Enter 2 numbers");
            int n1 = Convert.ToInt32(Console.ReadLine());
            int n2 = Convert.ToInt32(Console.ReadLine());
            int r = n1 % n2;
            int q = n1 / n2;
            Console.WriteLine($"The quotient is {q} and remainder is {r}");
        }

        //Create a function by name printnames.Develop a code to accept number
        //and name from the user using console.readline()
        //Print the name in console window as much as time the given number
        //Eg:
        //If user enters 3, then display your name for 3 times

        public void PrintNames()
        {
            Console.WriteLine("Enter a name:");
            String s = Console.ReadLine();
            String s1 = String.Join(" ", Enumerable.Repeat(s, 3));
            Console.WriteLine(s1);

        }


        static void Main(string[] args)
        {
            Program p = new Program();
            String o, c;
            do
            {
                Console.WriteLine("Choose one option\n 1.Find Greatest with elseif\n2.FindMax with builtin Max function\n 3.Employee Salary Calculation\n" +
                    "4.Find factorial\n5.Find Sum of 10 numbers\n6.Copy 2 strings \n 7.Swap 2 numbers without temp\n8. Divide a number" +
                    "\n9.Print numbers");
                o = Console.ReadLine();
                switch (o)
                {
                    case "1": p.Greatest(); break;
                    case "2": p.FindMax(); break;
                    case "3": p.Employee(); break;
                    case "4": p.Fact(); break;
                    case "5": p.Sum10Nums(); break;
                    case "6": p.CopyString(); break;
                    case "7": p.Swap(); break;
                    case "8": p.Divnums(); break;
                    case "9": p.PrintNames(); break;
                    default: Console.WriteLine("Select a valid option"); break;
                }
                Console.WriteLine("Do you want to continue Y or N:");
                c = Console.ReadLine().ToUpper();
                if (c != "Y" && c != "N")
                {
                    Console.WriteLine("Enter only Y or N :");
                    c = Console.ReadLine().ToUpper();
                }
            } while (c == "Y");

        }
    }
}
