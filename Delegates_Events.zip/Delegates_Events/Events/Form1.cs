﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Events
{
    public partial class Form1 : Form
    {
        MyEventClass ob=new MyEventClass();
        public Form1()
        {
            ob.myEvent += ob_myevent;
            InitializeComponent();
        }

        private void ob_myevent(string ms)
        {
            notifyIcon1.Icon = SystemIcons.Application;
            notifyIcon1.BalloonTipIcon = ToolTipIcon.Info;
            notifyIcon1.BalloonTipText = ms;
            notifyIcon1.ShowBalloonTip(500);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ob.subscribe();
        }
    }
}
