﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Events
{
    internal class MyEventClass
    {
        //1.create a delegate
        public delegate void mycustomdel(string ms);

        //2.create an event that uses delegate
        //public event delegate_name event_name
        public event mycustomdel myEvent;
        public void subscribe()
        {
            string[] str = { "message1", "message2", "message3" };
            foreach (string s in str)
            {
                //notify for every 5 sec
                Thread.Sleep(500);
                //event_name(item)
                myEvent(s);
            }
        }
    }
}
