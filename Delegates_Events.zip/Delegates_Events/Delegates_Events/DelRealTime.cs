﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_Events
{
    public delegate bool myrealdel(int x);
    internal class DelRealTime
    {
        public void StoreInFile(myrealdel d,int[] data)
        {
            foreach (int item in data)
            {
                if (d.Invoke(item))
                {
                    Console.WriteLine(item);
                }
            }
        }
    }
}
