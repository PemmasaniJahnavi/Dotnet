﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_Events
{
    internal class Program
    {

        public static bool Mylogic(int x)
        {
            return x > 40; //returns true if >50 else false
        }
        static void Main(string[] args)
        {
            //DelegateDemo d=new DelegateDemo();
            //d.Show(12);


            //MultiCast m = new MultiCast();
            //m.show();


            //int[] k = new int[] { 10, 20, 30, 40, 50, 60, 70 };
            //DelRealTime obj1 = new DelRealTime(); //create class object
            //myrealdel d = Mylogic; //create delegate obj and assign method directly
            //obj1.StoreInFile(d, k);

            int[] k = new int[] { 10, 20, 30, 40, 50, 60, 70 };
            DelRealTime d = new DelRealTime();
            d.StoreInFile(x => x > 50, k);//directly give logic code here

        }
    }
}
