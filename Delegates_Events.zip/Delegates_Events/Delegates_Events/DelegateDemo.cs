﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_Events
{
    internal class DelegateDemo
    {
       public delegate void myDelegate(int a); //delegate declaration

        //public void Even()
        //{
        //    Console.WriteLine("even method called");
        //}
        public void Odd(int a)
        {
            Console.WriteLine("Odd method called");
        }
        public void Show(int x)
        {
            myDelegate obj; //delegate instantiation
            if (x%2==0)
            {
                //obj = new myDelegate(Even);
                //obj = Even;
                //obj = delegate (int a) { Console.WriteLine("even method called"+ a); };
                obj = (a) => { Console.WriteLine("even number " + a); };
            }
            else
            {
                obj=new myDelegate(Odd);
            }
            obj.Invoke(x); //delegate invocation
        }
    }
}
