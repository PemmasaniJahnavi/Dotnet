﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_Events
{
    internal class MultiCast
    {
        public delegate string multidel();
        public string m1()
        {
            Console.WriteLine("m1 called");
            return "m1";
        }
        public string m2()
        {
            Console.WriteLine("m2 called");
            return "m2";
        }
        public string m3()
        {
            Console.WriteLine("m3 called");
            return ("m3");
        }
        public void show()
        {
            multidel ob = m1;
            ob += m2;
            ob+= m3;
            string s=ob.Invoke(); //both m1 and m2 are called at a time.
            Console.WriteLine(s);//the last called methods return value is collected.
            Console.WriteLine("================");
            Console.WriteLine(s);
            ob -= m1;
            ob.Invoke();

        }
    }
}
