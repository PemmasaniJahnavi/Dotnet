﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;
using Unity.Lifetime;

namespace DIdemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //you need to inject
            //IMath o = new servicecls();
            //client c = new client(o); //for constructor injection

            //for property injection and method injection
            //client c = new client();
            //c.propy = o;
            //c.show(o);

            IUnityContainer c = new UnityContainer();

            //Transient: it creates new instance every time
            //when i use IMath anywhere in application it creates an instance of service class
            //c.RegisterType<IMath, servicecls>();
            //c.RegisterType<client>(); // client object will be created by container


            //Scoped: it creates instance per request
            //c.RegisterType<IMath, servicecls>(new HierarchicalLifetimeManager());
            //c.RegisterType<client>(new HierarchicalLifetimeManager());


            //Singleton: it creates only one instance for application
            c.RegisterSingleton<IMath, servicecls>();
            c.RegisterSingleton<client>();


            var ob = c.Resolve<IMath>();//getting instance of IMath
            ob.Add(10, 20);
            var obj = c.Resolve<client>();//getting instance of client
            obj.show();


        }
    }
}
