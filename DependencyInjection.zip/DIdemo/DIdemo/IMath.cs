﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIdemo
{
    internal interface IMath
    {
        void Add(int x, int y);
    }

    class servicecls : IMath
    {
        public void Add(int x, int y)
        {
            Console.WriteLine($"The sum is {x+y}");
        }


    }
}
