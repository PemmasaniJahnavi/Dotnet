﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.WebSockets;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace DIdemo
{
    internal class client
    {
        //Injecting via constructor
        IMath m;
        public client(IMath ob)
        {
            m = ob;
        }

        //property injection
        //public IMath propy { get; set; }

        public void show()
        {
            //ob.Add(10, 10);
            m.Add(10, 10);
        }
    }
}
