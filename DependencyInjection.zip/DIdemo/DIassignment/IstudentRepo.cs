﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Threading;

namespace DIassignment
{
    public interface IStudentRepository
    {
        void AddStudent(Students student);
        List<Students> GetAllStudents();
        Students GetStudentById(int id);
        void UpdateStudent(Students student);
        void DeleteStudent(int id);
    }

    public class StudentRepo : IStudentRepository
    {
        private readonly Model1 m = new Model1();

        public void AddStudent(Students student)
        { 
            m.Student.Add(student);
            m.SaveChanges();
            Console.WriteLine("Student added successfully");
        }

        public void DeleteStudent(int id)
        {
            var res = m.Student.Find(id);
            if (res == null)
            {
                Console.WriteLine($"No student found with id {id} to delete.");
                return;
            }

            m.Student.Remove(res);
            m.SaveChanges();
            Console.WriteLine($"Student with id {id} deleted successfully.");
        }

        public List<Students> GetAllStudents()
        {
            var res = m.Student.ToList();
            //Console.WriteLine("{0,-6} {1,-25} {2,-35} {3}", "ID", "Name", "Email", "Age");
            //Console.WriteLine("________________________________________________________________________________");

            //foreach (var i in res)
            //{
            //    Console.WriteLine("{0,-6} {1,-25} {2,-35} {3}",i.StudentId,i.Name,i.Email,i.Age);
            //}
            return res;

        }

        public Students GetStudentById(int id)
        {
            var res = m.Student.Find(id);
            if (res == null)
            {
                Console.WriteLine($"No student found with id {id}.");
                return null;
            }

            Console.WriteLine($"{res.StudentId} {res.Name}, {res.Email}, {res.Age}");
            return res;
        }

        public void UpdateStudent(Students student)
        {
            var res = m.Student.Find(student.StudentId);
            if (res == null)
            {
                Console.WriteLine($"No student found to update.");
                return;
            }

            res.Name = student.Name;
            res.Email = student.Email;
            res.Age = student.Age;

            m.SaveChanges();
            Console.WriteLine($"Student updated successfully.");
        }
    }
}
