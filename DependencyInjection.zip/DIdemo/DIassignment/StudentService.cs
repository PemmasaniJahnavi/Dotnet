﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace DIassignment
{
    public class StudentService
    {
        private readonly IStudentRepository _repository;

        public StudentService(IStudentRepository repository)
        {
            _repository = repository;
        }

        public void AddStudent(string name, string email, int age)
        {
            Students student = new Students()
            {
                Name = name,
                Email = email,
                Age = age
            };
            _repository.AddStudent(student);
            Console.WriteLine("Added to database successfully");
        }

        public void ShowAllStudents()
        {
            
                List<Students> students = _repository.GetAllStudents();

                Console.WriteLine("{0,-6} {1,-25} {2,-35} {3}", "ID", "Name", "Email", "Age");
                Console.WriteLine(new string('-', 75));

                foreach (var s in students)
                {
                    Console.WriteLine("{0,-6} {1,-25} {2,-35} {3}", s.StudentId, s.Name, s.Email, s.Age);
                }
            
        }


    }
}
