﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace DIassignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IUnityContainer u = new UnityContainer();

            u.RegisterType<IStudentRepository,StudentRepo>();
            u.RegisterType<StudentService>();

            var ob = u.Resolve<IStudentRepository>();
            var ob1 = u.Resolve<StudentService>();

            //For adding data

            //ob1.AddStudent("Anil","anil@gmail.com",26);

            //var student = new Students
            //{
            //    Name = "Ganesh",
            //    Email = "ganesh@gmail.com",
            //    Age = 22
            //};
            //ob.AddStudent(student);


            //For Displaying
            //ob1.ShowAllStudents();
            //ob.GetAllStudents();
            //ob.GetStudentById(3);

            //For removing
            //ob.DeleteStudent(5);

            //For updating
            //var student = new Students
            //{
            //    StudentId = 4,
            //    Name = "Geevan",
            //    Email = "geevan@gmail.com",
            //    Age = 28
            //};
            //ob.UpdateStudent(student);

        }
    }
}
