﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOF
{
    //When i want a template to be fixed , means the steps or order of exxeution should be same but they can be used by any.
    //Create a abstract class where we define sequence of steps and define abstract function
    //Later inherit this abstract class and implement methods using override keyword and then simply call Action method
    //Instead of calling all methods on client side, they are called sequentially here avoiding risk of potential sequence errors
    internal abstract class FileProcessor
    {
        public void DoAction()
        {
            connect();
            read();
            process();
            close();
        }
        public abstract void connect();
        public abstract void read();
        public abstract void process();
        public void close()
        {
            Console.WriteLine("The file closed");
        }

    }
    internal class JsonProcessor:FileProcessor
    {
        public override void connect()
        {
            Console.WriteLine("connect to the Json file");
        }
        public override void read()
        {
            Console.WriteLine("Read the json file");
        }
        public override void process()
        {
            Console.WriteLine("Process of json file");
        }
    }
    internal class XmlProcessor:FileProcessor
    {
        public override void connect()
        {
            Console.WriteLine("connect to the Xml file");
        }
        public override void read()
        {
            Console.WriteLine("Read the Xml file");
        }
        public  override void process()
        {
            Console.WriteLine("Process of Xml file");
        }
    }
}
