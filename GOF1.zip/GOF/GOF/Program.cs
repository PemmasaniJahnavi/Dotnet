﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOF
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ////For Singleton class
            //var obj = SingletonDemo.GetInstance();
            //var obj1 = SingletonDemo.GetInstanceProp;
            //Console.WriteLine(obj.GetHashCode());
            //Console.WriteLine(obj1.GetHashCode());

            ////For Factory Pattern
            //Factory f = new Factory();
            //var v = f.Getvehicle(3);
            //v.showdetails();

            ////For Prototype pattern
            //Prototype p = new Prototype();
            //p.MName = "Iphone";
            //p.Price = 50000;
            //p.Company = "Apple";
            //Console.WriteLine($"{p.MName} {p.Price} {p.Company}");
            //Prototype p1 = (Prototype)p.Clone();
            //Console.WriteLine($"{p1.MName} {p1.Price} {p1.Company}");
            //p1.MName = "GalaxyA32";
            //p1.Company = "Samsung";
            //Console.WriteLine($"{p1.MName} {p1.Price} {p1.Company}");

            ////For Adapter Pattern
            //IInterface i = new Newclass();
            //i.ShowDetails("Happy Dusshera");
            //IInterface a = new Adapter(new OldClass());
            //a.ShowDetails("Adapter Pattern used");

            ////For Facade Pattern
            //Product f = new Product();
            //f.BuyProduct();

            ////For Strategy Pattern
            //PaymentContext pc = new PaymentContext();
            //pc.SetPaymentStrategy(new PayPal());
            //pc.Pay(500);
            //pc.SetPaymentStrategy(new CreditCard());
            //pc.Pay(500);

            //For Template Pattern
            FileProcessor f = new JsonProcessor();
            f.DoAction();
            f = new XmlProcessor();
            f.DoAction();
           




        }
    }
}
