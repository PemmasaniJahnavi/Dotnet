﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOF
{
    //client never uses class directly nor creates obj, just passes argument, based on arg it returns object.
    //All objs created in a single place (centralized), other files only call obj.
    //Makes application loosely coupled, enables usage for future introductions(like new vehicle/brand added)


    //create interface that is used by all classes
    //write a factory class to create all objects
    //return the type of object based on parameter passed by user,return type is always interface
    public interface Ivehicle
    {
        void showdetails();
    }
    public class car : Ivehicle
    {
        public void showdetails()
        {
            string[] st = { "Maruthi", "BMW", "BENZ" };
            foreach (string s in st)
            {
                Console.WriteLine(s);
            }
        }
    }
        public class bike : Ivehicle
        {
            public void showdetails()
            {
                string[] st = { "Hero", "Honda", "Yamaha" };
                foreach (string s in st)
                {
                    Console.WriteLine(s);
                }
            }
        }
    public class truck : Ivehicle
    {
        public void showdetails()
        {
            string[] st = { "abc", "xyz", "mnp" };
            foreach (string s in st)
            {
                Console.WriteLine(s);
            }
        }
    }
    public class Factory
        {
            //all object are created here
            public Ivehicle Getvehicle(int x)
            {
                if (x == 1)
                {
                    return new car();
                }
                else if (x == 2)
                {
                    return new bike();
                }
                else if (x == 3)
                {
                    return new truck();
                }
                else
                    return null;
            }
        }

    }
