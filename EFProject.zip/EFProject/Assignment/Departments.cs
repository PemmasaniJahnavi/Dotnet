﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    public class Departments
    {
        [Key]
        public int DeptID { get; set; }

        [Column("DepartmentName", TypeName = "varchar")]
        [StringLength(20)]
        [RegularExpression(@"^Finance || HR$")]
        public string DName1 { get; set; }

        [Column(TypeName = "varchar")]
        [StringLength(20)]
        public string Manager { get; set; }
        public DateTime DEdit { get; set; }

        public ICollection<Employees> Employees { get; set; }
    }
}
