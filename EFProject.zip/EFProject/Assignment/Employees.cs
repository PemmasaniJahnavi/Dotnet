﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
        public class Employees
        {
        [Key]
        [Column("EmployeeId", TypeName = "varchar")]
        [StringLength(10)]
        [RegularExpression(@"^E\d{3}$", ErrorMessage = "Invalid EmployeeId")]
        public string EmpId { get; set; }

        [Column("EmployeeName", TypeName = "varchar")]
        [StringLength(20)]
        public string EmpName { get; set; }

        [Range(50000,150000)]
        public int Salary { get; set; }
        public DateTime DOB { get; set; }

        
        //[Column("DeptID")]
        public int DeptID { get; set; }
        [ForeignKey("DeptID")]
        public Departments Department {  get; set; }

    }

}
