﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EF_CodeFirst
{
    public class IplClass
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column(TypeName = "varchar")]
        [RegularExpression(@"^T\d{3}$",ErrorMessage ="Invalid TeamId")]
        public string TeamId { get; set; }
        
        [Column("TeamName",TypeName ="varchar")]
        [StringLength(20)]
        [Required(ErrorMessage = "Please enter teamname")]
        public string TName { get; set; }

        [Column(TypeName = "varchar")]
        [MinLength(4)]
        [MaxLength(13)]
        [Required(ErrorMessage = "Please enter captainname")]
        public string Captain { get; set; }

        [Column(TypeName = "varchar")]      
        public string State { get; set; }
       
        public int Budget { get; set; }
    }
}
