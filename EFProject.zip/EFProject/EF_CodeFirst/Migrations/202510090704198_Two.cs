﻿namespace EF_CodeFirst.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Two : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.IplClasses",
                c => new
                    {
                        TeamId = c.String(nullable: false, maxLength: 128, unicode: false),
                        TeamName = c.String(nullable: false, maxLength: 20, unicode: false),
                        Captain = c.String(nullable: false, maxLength: 13, unicode: false),
                        State = c.String(maxLength: 8000, unicode: false),
                        Budget = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.TeamId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.IplClasses");
        }
    }
}
