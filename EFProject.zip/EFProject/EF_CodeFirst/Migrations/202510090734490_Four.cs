﻿namespace EF_CodeFirst.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Four : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Menus", "Img");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Menus", "Img", c => c.Int(nullable: false));
        }
    }
}
