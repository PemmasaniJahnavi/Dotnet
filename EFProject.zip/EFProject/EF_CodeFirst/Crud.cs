﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace EF_CodeFirst
{
    internal class Crud
    {
        Model1 md = new Model1();

       
            public void ShowMenu()
            {
            var res = from t in md.Menus
                      select t;
            foreach (var item in res)
            {
                Console.WriteLine($"{item.MenuId} {item.Name} {item.Price} {item.Type}");
            }
            Console.WriteLine("==============================");


        }
        public void AddMenu()
        {
            Menu m = new Menu();
            //logic to add new item into menu
            Console.WriteLine("Enter the menu details as follows");
            Console.WriteLine("enter name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter price:");
            int price = int.Parse(Console.ReadLine());
            Console.WriteLine("enter type:");
            string type = Console.ReadLine();
            Console.WriteLine("enter description:");
            string desc = Console.ReadLine();
            m.Name = name;
            m.Price = price;
            m.Type = type;
            m.Description = desc;

            md.Menus.Add(m);
            md.SaveChanges();
            Console.WriteLine("menu item added");
            Console.WriteLine("=====================");

        }
        public void IplAdd()
        {
            IplClass i = new IplClass();
            //logic to add new item into menu
            Console.WriteLine("Enter the Ipl details as follows");
            Console.WriteLine("enter team id:");
            string tid = Console.ReadLine();
            Console.WriteLine("enter team name:");
            string tname = Console.ReadLine();
            Console.WriteLine("enter captain name:");
            string cname = Console.ReadLine();
            Console.WriteLine("enter state:");
            string state = Console.ReadLine();
            Console.WriteLine("enter budget");
            int bud = int.Parse(Console.ReadLine());

            i.TeamId = tid;
            i.TName = tname;
            i.Captain = cname;
            i.State = state;
            i.Budget = bud;
            md.Ipls.Add(i);
            md.SaveChanges();
            Console.WriteLine("Ipl team data added");
            Console.WriteLine("=====================");
        }

        public void CheckErrors()
        {
            Model1 ob = new Model1();
            try
            {
                IplClass m = new IplClass() { TeamId = "T12A", Captain = "Patt", State = "Telangana", Budget = 2500 };

                //ob.Ipls.Add(m);
                ob.SaveChanges();
                Console.WriteLine("Record Saved Successfully");

            }
            catch (Exception e)
            {
                var res = ob.GetValidationErrors();

                foreach (var item in res)
                {
                    if (item.ValidationErrors.Count > 0)
                    {
                        foreach (var err in item.ValidationErrors)
                        {
                            Console.WriteLine(err.ErrorMessage);
                        }

                    }
                }
            }
        }
    }
}
