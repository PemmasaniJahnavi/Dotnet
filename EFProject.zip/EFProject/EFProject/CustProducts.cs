﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;

namespace EFProject
{
    
    internal class CustProducts
    {
        MoviesDBEntities1 dc1 = new MoviesDBEntities1();
        public void Ravi()
        {
            //var res = dc1.Orders.Where(o => o.Customer.CustId == o.CustId && o.Customer.CustName == "Ravi Kumar");
            var res = from t in dc1.Orders join c in dc1.Customers
                      on t.CustId equals c.CustId where c.CustName == "Ravi kumar"
                      select t;
            foreach (var v in res)
            {
                Console.WriteLine($"{v.OrderId} {v.OrderDate}");
            }
            Console.WriteLine("==================");

        }

        public void Laptop_Phone()
        {
            var res = dc1.Customers.Where(c => c.Orders.Any(o => o.Product.ProductName == "Laptop")
            && c.Orders.Any(o => o.Product.ProductName == "Smartphone")).
                Select(c =>new { c.CustId, c.CustName});
            foreach (var v in res)
            {
                Console.WriteLine($"{v.CustId} {v.CustName}");
            }
            Console.WriteLine("==================");

        }

        public void List_Order_Qty()
        {
           var res = dc1.Customers.SelectMany(o => o.Orders).
           Select(o => new { custname = o.Customer.CustName, productname = o.Product.ProductName, o.Qty, total =
           (o.Qty * o.Product.Price) });

            //var res = from c in dc1.Customers
            //          join o in dc1.Orders on c.CustId equals o.CustId
            //          join p in dc1.Products on o.PId equals p.PId
            //          select new { c.CustName, p.ProductName, o.Qty, TotalPrice = o.Qty * p.Price };
            foreach(var v in res)
            {
                Console.WriteLine($"{v.custname} {v.productname} {v.Qty} {v.total}");
            }
            Console.WriteLine("==================");
        }

        public void Total_Orders()
        {
            var res = dc1.Customers.Select(s=> new {s.CustName,TOrder=s.Orders.Count()});
            foreach (var v in res)
            {
                Console.WriteLine($"{v.CustName} {v.TOrder}");
            }
            Console.WriteLine("==================");
        }

        public void Total_Orders_one()
        {
            var res = dc1.Customers.Where(t=>t.Orders.Count()>1).Select(s => new { s.CustName, TOrder = s.Orders.Count() });
            foreach (var v in res)
            {
                Console.WriteLine($"{v.CustName} {v.TOrder}");
            }
            Console.WriteLine("==================");
        }
    }
}
