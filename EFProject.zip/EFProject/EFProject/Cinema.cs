﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Common.CommandTrees;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFProject
{
    internal class Cinema
    {
        MoviesDBEntities1 dc=new MoviesDBEntities1();
        public void ShowAllMovies()
        {
            var res = from t in dc.Movies
                      select t;
            foreach (var item in res)
            {
                Console.WriteLine($"{item.MovieId} {item.MovieName} {item.Actor} {item.Actress} {item.YOR}");
            }
            Console.WriteLine("==============================");

            
        }
        public void ShowById(int i)
        {
            Console.WriteLine("Inside ShowById");
            var res = dc.Movies.Where(t => t.MovieId == i).FirstOrDefault();
            Console.WriteLine($"{res.MovieId} {res.MovieName} {res.Actor} {res.Actress} {res.YOR}");
            Console.WriteLine("==============================");


        }
        public void AddMovie()
        {
            Console.WriteLine("Inside AddMovie Method");
            Movie m = new Movie() { MovieId = 7, MovieName = "Hanuman", Actor = "Teja Sajja", Actress = "Amulya", YOR = 2025 };           
            dc.Movies.Add(m);// Adds the object to movies collection
            dc.SaveChanges();//adds the values to database
            Console.WriteLine("Added row into database successfully");
            Console.WriteLine("==============================");

        }
        public void DeleteMovie(int id)
        {
            Console.WriteLine("Inside delete method");
            var res = dc.Movies.Where(t => t.MovieId == id).FirstOrDefault();
            dc.Movies.Remove(res);
            int i=dc.SaveChanges();
            Console.WriteLine($"{i} rows deleted");
            Console.WriteLine("==============================");

        }
        public void UpdateMovie(int id)
        {
            Console.WriteLine("Inside update method");
            Console.WriteLine("Give YOR for the given Id");
            int u = int.Parse(Console.ReadLine());
            var res = dc.Movies.Where(t => t.MovieId == id).FirstOrDefault();
            res.YOR = u;
            int i=dc.SaveChanges();
            Console.WriteLine($"{i} rows updated");
            Console.WriteLine("==============================");
        }

        public void Useproc(int id)
        {
            Console.WriteLine("Inside the method ShowByid using proc");
            var res=dc.ShowMoviebyId(id).FirstOrDefault();
            Console.WriteLine($"{res.MovieId} {res.MovieName} {res.Actor} {res.Actress} {res.YOR}");
            

        }

        public void RunSql()
        {
            //how to use Sql queries
            //dc.Database.SqlQuery<Movie>("select * from Movies where YOR>2015");
            var v=dc.Database.SqlQuery<Movie>("select * from Movie where Actor like '%h'");
            foreach(var v1 in v)
            {
                Console.WriteLine($"{v1.Actor} {v1.MovieName}");
            }

        }

        public void DmlQuery()
        {
            var i=dc.Database.ExecuteSqlCommand("Insert into Movie values (8,'Titanic','Leo','kate',1998)");
            Console.WriteLine($"{i} rows inserted by dml query operation");
        }

        public void DisplayLog()
        {
            //To track what query has be generated for Linq by the EF, can see the time taken to process the request, data transfer info
            dc.Database.Log = Console.WriteLine;// this says to show all log data in the command prompt

        }
    }
}
