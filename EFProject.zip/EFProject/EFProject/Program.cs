﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFProject
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Cinema c=new Cinema();
            //c.ShowById(3);
            //c.AddMovie();
            //c.UpdateMovie(7);
            //c.DeleteMovie(7);
            //c.Useproc(2);
            //c.RunSql();
            //c.DmlQuery();
            //c.DisplayLog();
            //c.ShowAllMovies();

            CustProducts cd = new CustProducts();
            //cd.Ravi();
            //cd.Laptop_Phone();
            //cd.List_Order_Qty();
            //cd.Total_Orders();
            //cd.Total_Orders_one();
        }
    }
}
