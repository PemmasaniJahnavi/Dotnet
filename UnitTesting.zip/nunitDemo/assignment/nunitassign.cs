﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment
{
    internal class nunitassign
    {

        public bool IsPalindrome(string input)
        {
            if (string.IsNullOrEmpty(input)) return false;
            var reversed = new string(input.Reverse().ToArray());
            return input.Equals(reversed, StringComparison.OrdinalIgnoreCase);
        }

    }

    public class MathUtils
    {
        public bool IsEven(int number) => number % 2 == 0;
    }

    public class Validator
    {
        public void CheckAge(int age)
        {
            if (age < 18)
                throw new ArgumentException("Age must be 18 or older");
        }
    }
}
