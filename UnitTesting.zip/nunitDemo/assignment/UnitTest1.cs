namespace assignment
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {

        }

        //[Test]
        //[TestCaseSource(nameof(palindrome))]
        //public void Test1(string t)
        //{
        //    nunitassign n=new nunitassign();
        //    Assert.IsTrue(n.IsPalindrome(t));
        //}

        //public static IEnumerable<TestCaseData> palindrome()
        //{
        //    yield return new TestCaseData("madam");
        //    yield return new TestCaseData("hello");
        //    yield return new TestCaseData("");           
        //}

        [Test]
        [TestCaseSource(nameof(acc))]
        public void Test2(string name, int bal,int amt,string action)
        {
            BankAccount b = new BankAccount(name,bal);
            if (action == "deposit")
            {
                b.Deposit(amt);
                Assert.Greater(b.Balance, bal);
            }
            else
            {
                b.Withdraw(amt);
                Assert.Less(b.Balance, bal);
            }                       
        }

        public static IEnumerable<TestCaseData> acc()
        {
            yield return new TestCaseData("divya",500,1000,"deposit");
            yield return new TestCaseData("div",1000,100,"withdraw");
            yield return new TestCaseData("deena",2000,3000,"withdraw");
        }

        [Test]
        [TestCase("2025-10-11")]
        [TestCase("2025-10-10")]
        //[TestCaseSource(nameof(d))]
        public void day(DateTime date)
        {
            DateUtils u=new DateUtils();
            //var week=new DateTime(y,m,d);
            Assert.IsTrue(u.IsWeekend(date));
        }
        //public static IEnumerable<TestCaseData> d()
        //{
        //    yield return new TestCaseData("2025/10/11");
        //    yield return new TestCaseData("2025/10/10");
        //}

        [Test]
        [TestCaseSource(nameof(o))]
        public void eo(int x)
        {
            MathUtils m=new MathUtils();
            Assert.IsTrue(m.IsEven(x));
        }

        public static IEnumerable<TestCaseData> o()
        {
            yield return new TestCaseData(11);
            yield return new TestCaseData(10);
        }

        [Test]
        [TestCase(17)]
        public void age(int age)
        {
            Validator v=new Validator();
            var r = "Age must be 18 or older";            
            var g = Assert.Throws<ArgumentException>(() => v.CheckAge(age));
            Assert.AreEqual(r, g.Message);
        }
    }
}