﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment
{
    public class Tests2
    {
        SessionManager s = new SessionManager();

        [SetUp]
        public void Setup()
        {
            s.Start();
        }

        [Test]
        //[TestCaseSource(nameof(a))]
        public void session()
        {
                Assert.IsTrue(s.IsActive);
        }
        //public static IEnumerable<TestCaseData> a()
        //{
        //    yield return new TestCaseData("start");
        //    yield return new TestCaseData("end");
        //}
        [Test]
        [TearDown]
        public void TearDown()
        {
            s.End();
        }
    }
}
