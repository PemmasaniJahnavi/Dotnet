namespace nunitDemo
{
    public class Tests
    {
        //unit testing happens
        [Test]
        //[TestCase (1,2,3)]
        [TestCaseSource(nameof(MyTestData))]
        public void AddTest(int a, int b, int c)
        {
            //Arrange : keeping all variables and objects ready
            mymathclass ob = new mymathclass();
            //int a = 5, b = 10;

            ////Act
            int d = ob.Add(a, b);

            //Assert
            //Assert.AreEqual(d, c);
            Assert.That(d, Is.EqualTo(c));
        }

        //public static IEnumerable<TestCaseData> MyTestData()
        //{
        //    yield return new TestCaseData(2, 4, 6);
        //    yield return new TestCaseData(4, 8, 11);
        //    yield return new TestCaseData(3, 3, 6);
        //    yield return new TestCaseData(6, 5, 11);
        //    yield return new TestCaseData(8, 9, 17);
        //    yield return new TestCaseData(2, 3, 5);
        //}

        public static IEnumerable<object> MyTestData()
        {
            foreach (var line in File.ReadAllLines("C:/Users/divya.t2/C# training/MyData.csv"))
            {
                var parts = line.Split(',');
                yield return new object[]
                    {
                        int.Parse(parts[0]),
                        int.Parse(parts[1]),
                        int.Parse(parts[2])
                    };
            }
        }

        [Test]
        [Category("db")]
        [Ignore("incomplete logic")]
        public void MultiplyTest()
        {
            //Arrange : keeping all variables and objects ready
            mymathclass ob = new mymathclass();
            int a = 5, b = 10;

            //Act
            int c = ob.multiply(a, b);

            //Assert

            Assert.That(c, Is.EqualTo(50));
        }
        [Test]
        [Category("db")]
        public void DivideTest()
        {
            //Arrange : keeping all variables and objects ready
            mymathclass ob = new mymathclass();
            int a = 50, b = 0;
            var e = "cannot divide by zero";
            //Act          
            //Assert
            var g = Assert.Throws<DivideByZeroException>(() => ob.divide(a, b));
            Assert.AreEqual(e, g.Message);
            //Assert.That(c, Is.EqualTo(5));
        }
    }
}
