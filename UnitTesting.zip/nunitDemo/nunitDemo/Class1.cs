﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nunitDemo
{
    internal class Lifecycle
    {
        [SetUp]
        public void a()
        {
            var res = File.AppendText("C:/Users/divya.t2/C# training/lifecycle.txt");
            res.WriteLine("set up method is called");
            res.Dispose();
        }

        [TearDown]
        public void b()
        {
            var res = File.AppendText("C:/Users/divya.t2/C# training/lifecycle.txt");
            res.WriteLine("tear down method is called");
            res.Dispose();
        }

        [OneTimeSetUp]
        public void c()
        {
            var res = File.AppendText("C:/Users/divya.t2/C# training/lifecycle.txt");
            res.WriteLine("once set up method is called");
            res.Dispose();
        }

        [OneTimeTearDown]
        public void d()
        {
            var res = File.AppendText("C:/Users/divya.t2/C# training/lifecycle.txt");
            res.WriteLine("once tear down method is called");
            res.Dispose();
        }

        [Test]
        public void m1()
        {
            Assert.That(0,Is.EqualTo(0));
            var res = File.AppendText("C:/Users/divya.t2/C# training/lifecycle.txt");
            res.WriteLine(" method1 is called");
            res.Dispose();
        }

        [Test]
        public void m2()
        {
            Assert.That(0, Is.EqualTo(0));
            var res = File.AppendText("C:/Users/divya.t2/C# training/lifecycle.txt");
            res.WriteLine(" method2 is called");
            res.Dispose();
        }
    }
}
