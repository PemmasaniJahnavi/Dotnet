﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using mylib;

namespace nunitDemo
{
    internal class TDDTest
    {
        //TDDDemo1 ob = new TDDDemo1();
        //public void TestAdd()
        //{
        //    int c = ob.Add(10, 20);
        //    Assert.AreEqual(10, c);
        //}

        

        Class1 ob=new Class1();
        class2 ob1 = new class2();
        [Test]
        public void TestAdd()
        {
            int c = ob.Add(10, 20);
            Assert.AreEqual(30, c);
        }
        [Test]
        public void TestDivide()
        {
            int c = ob1.mul(10, 20);
            Assert.AreEqual(200, c);
        }
        [Test]
        public void TestMultiply()
        {
            int c = ob1.divide(20, 10);
            Assert.AreEqual(2, c);
        }

        public void sub()
        {

        }
    }
}
