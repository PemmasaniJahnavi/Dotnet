﻿
namespace nunitDemo
{
    internal class TDDDemo1
    {
        public TDDDemo1()
        {

        }       
    }
}