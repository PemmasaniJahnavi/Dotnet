﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nunitDemo
{
    internal class TDDDemo
    {
        internal int Add(int v1, int v2)
        {
            throw new NotImplementedException();
        }
    }
}
