﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nunitDemo
{
    internal class mymathclass
    {
        public int Add(int x,int y)
        {
            return x + y;
        }

        public int multiply(int  x,int y)
        {
            return x * y;
        }

        public int divide(int x,int y)
        {
            try
            {
                return x / y;
            }
            catch (DivideByZeroException e)
            {
                
                throw new DivideByZeroException("cannot divide by zero");
            }
            

        }
    }
}
