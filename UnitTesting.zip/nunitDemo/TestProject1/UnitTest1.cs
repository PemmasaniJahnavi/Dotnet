using System.Collections;

namespace TestProject1
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            Assert.Equal(1, 1);
            Assert.StrictEqual(1, 1);
        }

        [Theory]
        //[InlineData(1,2,3)]
        //[MemberData(nameof(testdata))]
        [ClassData(typeof(abc))]
        public void Test2(int a, int b, int c)
        {
            Assert.Equal(c, a + b);
        }

        //public static IEnumerable<object[]> testdata =>
        //new List<object[]>
        //{ new object[] {1,2,3 },
        // new object[] {5,2,7 }
        //};


    }
    class abc : IEnumerable<object[]>
    {
        private readonly List<object[]> _data = new()
        {
         new object[] {1,2,3 },
         new object[] {5,2,7 }
        };
        public IEnumerator<object[]> GetEnumerator()
        {
            return _data.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

    }

}