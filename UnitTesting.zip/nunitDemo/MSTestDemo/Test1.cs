﻿namespace MSTestDemo
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Assert.AreEqual(1, 1);
        }

        [TestMethod]
        //[DataRow(10,20,30)]
        //[DataRow(10, 20, 20)]
        //[DataRow(20, 20, 40)]
        [DynamicData(nameof(testdata))]
        public void add(int x, int y,int z)
        {
            Assert.AreEqual(x+y, z);
        }

        public static IEnumerable<object[]> testdata =>
     new List<object[]>
     { new object[] {1,2,3 },
         new object[] {5,2,7 }
     };
    }
}
