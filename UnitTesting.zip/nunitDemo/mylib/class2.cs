﻿namespace mylib
{
    public class class2
    {
        public int divide(int x, int y)
        {
            return x / y;
        }

        public int mul(int x, int y)
        {
            return x * y;
        }
    }
}