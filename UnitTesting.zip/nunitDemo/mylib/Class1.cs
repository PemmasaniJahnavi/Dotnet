﻿namespace mylib
{
    public class Class1
    {
        public int Add(int x,int y)
        {
            return x + y;
        }

        
    }
}
