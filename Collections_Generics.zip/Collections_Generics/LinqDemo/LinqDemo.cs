﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace LinqDemo
{
    internal class LinqDemo
    {
        List<Student> s = new List<Student>()
            {
                new Student() { SId = 1, SName = "Laasya", TotalMarks = 100, Class = 12},
                new Student() { SId = 2, SName = "Vaishu", TotalMarks = 98, Class = 10 },
                new Student() { SId = 3, SName = "Hasini", TotalMarks = 67, Class = 11 },
                new Student() { SId = 4, SName = "Aishu", TotalMarks = 89, Class = 9 },
            };
        public void QEDemo1()
        {
            //PRINT ALL THAT STARTS WITH C
            string[] data = { "Java", "C", "C++", "C#", "Python" };
            var res = from t in data where t.StartsWith("C") select t;

            foreach (var v in res)
            { 
            Console.WriteLine(v);
            }
            Console.WriteLine("=================");

            //PRINT ALL EVEN NUMBERS
            int[] d = { 10, 11, 12, 13, 14, 15 };
            var r = from t in d where t % 2 == 0 select t;
            foreach (var v in r)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine("=================");

            //PRINT ALL THAT STARTS WITH C OR J AND LENGTH LESS THAN 2
            string[] s1 = { "java", "c#", "c++", "c", "python" };
            var res1 = from t in s1
                      where t.Length < 2 && (t.StartsWith("c") || t.StartsWith("J"))
                      select t;
            foreach (var v in res1)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine("=================");
        }
        public void QEDemo2()
        {
           
            var res = from t in s where t.SName.EndsWith("a") select t;
            Console.WriteLine("Names that end with 'A'");
            foreach(var v in res)
            {
                Console.WriteLine($"{v.SId} {v.SName} {v.TotalMarks} {v.Class}");
            }
            Console.WriteLine("=====================");

            var res1 = from t in s
                       where t.TotalMarks > 80
                       orderby t.TotalMarks descending
                       select t;
            Console.WriteLine("Sort by Marks");
            foreach( var v in res1)
            {
                Console.WriteLine($"{v.SId} {v.SName} {v.TotalMarks} {v.Class}");
            }
            Console.WriteLine("=====================");


            //select will choose all the attributes but to specify use select new{ }, can rename and give alias name
            var res2=from t in s
                     select new {StudentId=t.SId, StudentName=t.SName};
            Console.WriteLine("Hide Marks and class, get only id and name by alias name");
            foreach (var v in res2)
            {
                Console.WriteLine($"{v.StudentId} {v.StudentName}");
            }
            Console.WriteLine("=====================");


            //Create the LINQ first then add data and check output, it shows all data
            //As we have deferred execution for LINQ, to make it immediate use ToList()
            var res3 = (from t in s
                       select new {t.SId,t.SName}).ToList();
            s.Add(new Student() { SId = 5, SName = "Divya", TotalMarks = 85, Class = 8 });
            foreach(var v in res3)
            {
                Console.WriteLine($"{v.SId} {v.SName}");
            }
        }

        public void PartitionOp()
        {
            //using lambda expression 
            var res = s.Where(t => t.TotalMarks > 85 && t.SName.EndsWith("u"));
            foreach( var v in res)
            {
                Console.WriteLine($"{v.SId} {v.SName}");
            }
            Console.WriteLine("=====================");

            //using TakeWhile
            var res1 = s.TakeWhile(t => t.TotalMarks != 67);
            foreach (var v in res1)
            {
                Console.WriteLine($"{v.SId} {v.SName}  {v.TotalMarks}");
            }
            Console.WriteLine("=====================");

            //using SkipWhile
            var res2 = s.SkipWhile(t => t.TotalMarks != 67);
            foreach (var v in res2)
            {
                Console.WriteLine($"{v.SId} {v.SName}  {v.TotalMarks}");
            }
            Console.WriteLine("=====================");

            //using Skip and Take
            var res3 = s.Skip(2);
            var res4 = s.Take(3);
            foreach (var v in res2)
            {
                Console.WriteLine($"{v.SId} {v.SName}  {v.TotalMarks}");
            }
            Console.WriteLine("=====================");
            foreach (var v in res4)
            {
                Console.WriteLine($"{v.SId} {v.SName}  {v.TotalMarks}");
            }
            Console.WriteLine("=====================");


            //Chaining method - use more tham one function in lambda expression.
            //Print 3rd highest marks from records.
            var m = s.OrderByDescending(t => t.TotalMarks).Take(3).Skip(2);
            foreach (var v in m)
            {
                Console.WriteLine($"{v.SId} {v.SName}  {v.TotalMarks}");
            }
            Console.WriteLine("=====================");

        }

        public void SetOperations()
        {
            int[] a = { 10, 20, 30, 40,30,40 };
            int[] b = { 30, 40, 50, 60 };

            //var res = a.Except(b);
            //var res = a.Union(b);
            //var res = a.Distinct();
            var res = a.Intersect(b);
            foreach (var v in res)
            {
                Console.WriteLine(v);
            }

        }
        public void QuantifierDemo()
        {
            bool b = s.All(t => t.TotalMarks > 80);
            bool b1 = s.Any(t => t.TotalMarks == 100);

            Student s1 = new Student() { SId = 1, SName = "Laasya", TotalMarks = 100, Class = 12 };           
            bool b2 = s.Contains(s1);
            Console.WriteLine(b2);
            //bool b3 = s.Contains(SId = 6, SName = "Hk", TotalMarks = 85, Class = 7);
        }
    }
}
