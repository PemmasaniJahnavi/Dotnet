﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            LinqDemo ld=new LinqDemo();
            //ld.QEDemo1();
            //ld.QEDemo2();
            //ld.PartitionOp();
            //ld.SetOperations();
            ld.QuantifierDemo();
        }
    }
}
