﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assembly
{
    public class SimpleClass
    {
        public void Add(int a, int b)
        {
            Console.WriteLine($"The sum is {a+b}");
        }
        public void Sub(int a, int b)
        {
            Console.WriteLine($"The sum is {a - b}");
        }
        public void Divide(int a, int b)
        {
            Console.WriteLine($"The sum is {a/b}");
        }
    }
}
