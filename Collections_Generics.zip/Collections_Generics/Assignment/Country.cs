﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Country
    {
        Hashtable ht = new Hashtable();
        public void Add()
        {
            ht.Add(1, "India");
            ht.Add(2, "SriLanka");
            ht.Add(3, "Nepal");
            ht.Add(4, "Germany");
            ht.Add(5, "Russia");
        }
           
        public void Ask()
        {
            Console.WriteLine("Enter a key value");
            int i = Convert.ToInt32(Console.ReadLine());
            if (ht.ContainsKey(i))
            {
                Console.WriteLine(ht[i]);
            }
            else
                Console.WriteLine("The key not found in hashtable");
                     

        }
    }
}
