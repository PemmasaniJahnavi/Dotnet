﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //display country name based on key entered by user
            //Country c=new Country();
            //c.Add();
            //c.Ask();

            //Contact Management System.
            String c, o;
            do { 
            Console.WriteLine("Choose one option\n 1.Add an Element\n2.Display\n 3.Count\n" +
                    "4.Sort\n5.Find\n6.Clear all values \n 7.Check if the value exists\n 8.Remove a value\n8.Exit");
            ContactMs cms = new ContactMs();
            o = Console.ReadLine();
            
                switch (o)
                {
                    case "1": cms.AddContact(); break;
                    case "2": cms.Display(); break;
                    case "3": cms.Count(); break;
                    case "4": break;
                    case "5": break;
                    case "6": break;
                    case "7":  break;
                    case "8": cms.RemoveContact(); break;
                    case "9":  break;
                    case "10": break;
                    default: Console.WriteLine("Select a valid option"); break;
                }
                Console.WriteLine("Do you want to continue Y or N:");
                c = Console.ReadLine().ToUpper();
                if (c != "Y" && c != "N")
                {
                    Console.WriteLine("Enter only Y or N :");
                    c = Console.ReadLine().ToUpper();
                }
            } while (c == "Y");
        }
    }
}
