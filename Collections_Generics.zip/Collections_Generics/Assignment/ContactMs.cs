﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Assignment
{

//Override ToString() to display contact info in a neat format.
internal class Contact
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime DOB { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }

    }
    internal class ContactMs
    {
        List<Contact> l=new List<Contact>();

        public void AddContact()
        {
            Contact c = new Contact();
            Console.WriteLine("Enter Id:");
            c.Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name:");
            c.Name = Console.ReadLine();
            Console.WriteLine("Enter Email:");
            c.Email = Console.ReadLine();
            Console.WriteLine("enter Phone Number:");
            c.Phone = Console.ReadLine();
            c.DOB = DateTime.Now;
            if (l.Exists(l => l.Id == c.Id))
            {
                Console.WriteLine("Already Exists");
                return;
            }
            else
            {
                l.Add(new Contact() { Id = c.Id, Name = c.Name, DOB = c.DOB, Email = c.Email, Phone = c.Phone });
                foreach (Contact v in l)
                {
                    Console.WriteLine($"{v.Id} {v.Name}\n{v.Email}\n{v.Phone}\n{v.DOB}\n");
                    Console.WriteLine("========================");
                }
            }
        }
        public void Display()
        {
            foreach (var v in l)
            {
                Console.WriteLine($"{v.Id} {v.Name}\n{v.Email}\n{v.Phone}\n{v.DOB}\n");
                Console.WriteLine("========================");
            }

        }
        public void RemoveContact()
        {
            Console.WriteLine("Enter an id:");
            int i=int.Parse(Console.ReadLine());
            foreach (var v in l)
            {
                if (v.Id == i)
                    l.Remove(v);
            }           
        }

        public void FindContact(string s)
        {
            Console.WriteLine("search started");
            foreach(var v in l)
            {
                if(v.Email==s||v.Phone==s)
              
                    Console.WriteLine("Found details");
            }
            Console.WriteLine("Search ended");
        }

        public void Sort()
        {
            Console.WriteLine("Choose a sort option\n 1.by Name\n2.by Id");
            int i = int.Parse(Console.ReadLine());
            switch (i)
            {
                case 1:var res=l.OrderBy(t=>t.Id);
                    foreach(var v in res)
                    {
                        Console.WriteLine($"{v.Id} {v.Name} {v.Email}");
                    }
                    break;

                case 2:
                    var res1 = l.OrderBy(t => t.Name);
                    foreach (var v in res1)
                    {
                        Console.WriteLine($"{v.Id} {v.Name} {v.Email}");
                    }
                    break;
            }
        }

        public void Count()
        {
            int c = 0;
            foreach(var v in l)
            {
                c++;
            }
            Console.WriteLine($"Count:{c}");
        }

        public void ClearAll()
        {
            l.Clear();
            Console.WriteLine("All values cleared");
        }

        public void Check()
        {
            Console.WriteLine("enter the id");
            int id=Convert.ToInt32(Console.ReadLine());
            var res = l.Where(t => t.Id == id);
            if (res != null)
            {
                foreach (var v in res)
                {
                    Console.WriteLine($"{v.Id} {v.Name} {v.Email}");
                }
            }
            else
                Console.WriteLine("the id data not found.");
            
        }
    }
}
