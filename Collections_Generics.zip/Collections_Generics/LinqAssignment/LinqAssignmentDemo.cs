﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace LinqAssignment
{
    internal class LinqAssignmentDemo
    {
        List<Movies> li = new List<Movies>()
         {
           new Movies(){ MovieId=100, MovieName="Bahubali", Actor="Prabhas", Actress="Tamanna",YOR=2015 },
           new Movies(){ MovieId=200, MovieName="Bahubali2", Actor="Prabhas", Actress="Anushka",YOR=2017 },
           new Movies(){ MovieId=300, MovieName="Robot", Actor="Rajini", Actress="Aish", YOR=2010 },
           new Movies(){ MovieId=400, MovieName="3 idiots", Actor="Amir", Actress="kareena", YOR=2009 },
           new Movies(){ MovieId=500, MovieName="Saaho", Actor="Prabhas", Actress="shraddha",YOR=2019 },
         };

        List<Product> lp = new List<Product>()
{
new Product() { pid = 100, pname = "book", price = 1000, qty = 5 },
new Product() { pid = 200, pname = "cd", price = 2000, qty = 6 },
new Product() { pid = 300, pname = "toys", price = 3000, qty = 5 },
new Product() { pid = 400, pname = "mobile", price = 8000, qty = 6 },
new Product() { pid = 600, pname = "pen", price = 200, qty = 7 },
new Product() { pid = 700, pname = "tv", price = 30000, qty = 7 },
};

        public void LinqAssignment1()
        {
            //display list of movienames acted by prabhas
            var r1 = from t in li where t.Actor == "Prabhas"
                     select new {t.MovieName};
            foreach(var t in r1)
            {
                Console.WriteLine($"{t.MovieName}");
            }
            Console.WriteLine("=========================");

            //2. display list of all movies released in year 2019
            var r2 = from t in li
                     where t.YOR == 2019
                     select t;
            foreach (var t in r2)
            {
                Console.WriteLine($"{t.MovieName}");
            }
            Console.WriteLine("=========================");

            //3.display the list of movies who acted togeather by prabhas and anushka
            var r3 = from t in li
                     where t.Actor == "Prabhas" && t.Actress=="Anushka"
                     select new { t.MovieName };
            foreach (var t in r3)
            {
                Console.WriteLine($"{t.MovieName}");
            }
            Console.WriteLine("=========================");

            //4. display the list of all actress who acted with prabhas
            var r4 = from t in li
                     where t.Actor == "Prabhas"
                     select new { t.Actress };
            foreach (var t in r4)
            {
                Console.WriteLine($"{t.Actress}");
            }
            Console.WriteLine("=========================");

            //5. display the list of all moves released from 2010 - 2018
            var r5 = from t in li
                     where t.YOR <=2018 && t.YOR>=2010
                     select t;
            foreach (var t in r5)
            {
                Console.WriteLine($"{t.MovieName}");
            }
            Console.WriteLine("=========================");

            //6. sort YOR in descending order and display all its records
            var r6=from t in li orderby t.YOR descending select t;
            foreach (var t in r6)
            {
                Console.WriteLine($"{t.YOR} {t.MovieName} {t.Actor} {t.Actress}");
            }
            Console.WriteLine("=========================");


            //7.display max movies acted by each actor var r7=from t in li select 
            var res7 = (from t in li group t by t.Actor into a select new { Actor=a.Key, c=a.Count() });
            foreach (var v in res7)
            {
                Console.WriteLine($"{v.Actor} {v.c}");
            }
            Console.WriteLine("=========================");

            //8.display the name of all movies which is 5 charecters long
            var r8 = from t in li where t.MovieName.Length == 5 select t;
            foreach (var t in r8)
            {
                Console.WriteLine($"{t.YOR} {t.MovieName} {t.Actor} {t.Actress}");
            }
            Console.WriteLine("=========================");

            //9.display names of actor and actress where movie released in year 2017, 2009 and 2019
            int[] year = new int[] { 2017, 2009, 2019 };
            var v9= from t in li where t.YOR==2017|| t.YOR == 2019 || t.YOR == 2009 select t;
            var r9 = from t in li where year.Contains(t.YOR) select t;
            foreach (var t in r9)
            {
                Console.WriteLine($"{t.YOR} {t.MovieName} {t.Actor} {t.Actress}");
            }
            Console.WriteLine("=========================");

            //10.display the name of movies which start with 'b' and ends with 'i'
            var r10 = from t in li
                      where t.MovieName.ToUpper().StartsWith("B") && t.MovieName.ToUpper().EndsWith("I")
                      select t;
            foreach (var t in r10)
            {
                Console.WriteLine($"{t.YOR} {t.MovieName} {t.Actor} {t.Actress}");
            }
            Console.WriteLine("=========================");

            //11.display name of actress who not acted with rajini and print in descending order
            var r11 = from t in li where t.Actor != "Rajini" orderby t.Actress descending select new { t.Actress };
            foreach (var t in r11)
            {
                Console.WriteLine($"{t.Actress}");
            }
            Console.WriteLine("=========================");

            //12. display records in follwing format
            //moviename cast
            //bahubali prabhas-tammanna
            var v12 = from t in li select new { Moviename=t.MovieName,t.Actor,t.Actress };
            foreach(var v in v12)
            {
                Console.WriteLine($"{v.Moviename}   {v.Actor}-{v.Actress}");
            }
            Console.WriteLine("=========================");

        }

        public void LinqAssignment2()
        {
            //Write a Linq to query to sort based on string Length string[] st = { "India", "Srilanka", "canada", "Singapore" };
            string[] st = { "India", "Srilanka", "canada", "Singapore" };
            var r = st.OrderBy(t => t.Length);
            //or query method
            //var rq = from t in st orderby t.Length select t;
            foreach(var v in r)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine("=========================");

            //1.find second highest price
            var r1 = lp.OrderByDescending(t => t.price).Take(2).Skip(1);
            foreach (var v in r1)
            {
                Console.WriteLine($"{v.pid} {v.pname} {v.price} {v.qty}");
            }
            Console.WriteLine("=========================");

            //2.display top 3 highest price
            var r2 = lp.OrderByDescending(t => t.price).Take(3);
            foreach (var v in r2)
            {
                Console.WriteLine($"{ v.pid} { v.pname} {v.price} {v.qty}");
            }
            Console.WriteLine("=========================");


            //3. Find the sum of price where product names contains letter 'O'
            var r3 = lp.Where(t=>t.pname.ToUpper().Contains("O")).Sum(t => t.price);
            Console.WriteLine(r3);

            //4. find the product name ends with e and display only pid and pname (filter by column name)
            var r4 = lp.Where(t => t.pname.EndsWith("e"));
            foreach (var v in r4)
            {
                Console.WriteLine($"{v.pid} {v.pname}");
            }
            Console.WriteLine("=========================");

            //5. group all records by qty find max of price
            var r5 = lp.GroupBy(t => t.qty).Select(g => new { Q = g.Key, Max = g.Max(p => p.price) });
            foreach(var v in r5)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine("=========================");
        }
    }
}
