﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assembly;

namespace AssemblyDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SimpleClass sc=new SimpleClass();
            sc.Add(34, 56);
            sc.Sub(40, 32);
            sc.Divide(100, 5);
            Console.Read();
        }
    }
}
