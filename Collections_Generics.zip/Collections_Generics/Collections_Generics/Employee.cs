﻿using System;
using System.CodeDom;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Generics
{
    internal class Employee:IEnumerable
    {
        //Real case of using ArrayList more meaningfully
        //use IEnumerable interface for enabling iteration for this class object using foreach.
        ArrayList ar = new ArrayList();
        public void AddEmployee(string name)
        {
            ar.Add(name);
        }

        public void RemoveEmployee(string name)
        {
            ar.Remove(name);
        }
        public void ShowAllEmployees()
        {
            foreach (var v in ar)
            {
                Console.WriteLine(v);
            }
        }

        //Created indexer to get the values by index for the Employee class
        public string this[int i]
        {
            get
            {
                return ar[i].ToString();
            }
        }

        //Implement GetEnumerator of Ienumerable to enable foreach iteration for Employee object.
        public IEnumerator GetEnumerator()
            {
            return ar.GetEnumerator(); //return all the values to foreach object.
            }
    }
}
