﻿using System;
using System.Collections;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Generics
{
    internal class HashTableClass
    {
        public void HashTableDemo()
        {
            Hashtable h1=new Hashtable();
            h1.Add(1, "Jahnavi");
            h1.Add(2, "Vaishu");
            h1.Add(3, "Laasya");

            //print specific values
            Console.WriteLine(h1[1]);
            Console.WriteLine("===============================");

            //print all values
            foreach (DictionaryEntry item in h1)
            {
                Console.WriteLine(item.Key + " : "+item.Value);
            }
            Console.WriteLine("===============================");           

            //count the values
            Console.WriteLine(h1.Count);
            Console.WriteLine("===============================");

            //remove a value- it takes key value
            h1.Remove(3);

            //To get output in the insertion order
            SortedList s = new SortedList(h1);
            foreach (DictionaryEntry item in s)
            {
                Console.WriteLine(item.Key + " : " + item.Value);
            }


        }
    }
}
