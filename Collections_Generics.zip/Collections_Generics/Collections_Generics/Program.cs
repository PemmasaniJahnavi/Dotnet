﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Generics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ArrayListClass cd = new ArrayListClass();
            cd.ArrayListDemo();
            cd.ArrayListDemo1();

            HashTableClass ht = new HashTableClass();
            ht.HashTableDemo();

            StackClass sc = new StackClass();
            sc.StackDemo();

            QueueClass qc = new QueueClass();
            qc.QueueDemo();

            Employee e = new Employee();
            e.AddEmployee("Jahnavi");
            e.AddEmployee("Laasya");
            e.AddEmployee("Pallavi");
            e.ShowAllEmployees();
            Console.WriteLine("===============================");
            e.RemoveEmployee("Pallavi");
            e.ShowAllEmployees();
            Console.WriteLine("===============================");
            //using indexer with specific value
            Console.WriteLine(e[1]);
            Console.WriteLine("===============================");
            //We cannot directly enumerate the Employee object like below, it throws error - bcz it doesnot have GetEnumerator()
            //So 1st implement IEnumerable interface near the class and implement GetEnumerator method, then this foreach works.
            foreach (var v in e)
            {
                Console.WriteLine(v);
            }

        }
    }
}
