﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Generics
{
    internal class QueueClass
    {
        public void QueueDemo()
        {
            Queue q = new Queue();
            q.Enqueue("Bahubali");
            q.Enqueue("Ballaladeva");
            q.Enqueue("Kattapa");
            q.Enqueue("Devasena");

            //print values
            foreach(var v in q)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine("===============================");

            //remove the value and print
            Console.WriteLine(q.Dequeue());
            foreach (var v in q)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine("===============================");

            //The front item in queue
            Console.WriteLine(q.Peek());
        }
    }
}
