﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Generics
{
    internal class StackClass
    {
        public void StackDemo()
        {
            Stack s = new Stack();
            s.Push("Youtube");
            s.Push("Whatsapp");
            s.Push("Instagram");
            s.Push("Gaming");
            
            //print values
            foreach(var v in s)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine("===============================");

        //remove an item and print it
        Console.WriteLine(s.Pop());
            foreach (var v in s)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine("===============================");

            //check item at top
            Console.WriteLine(s.Peek());
            Console.WriteLine("===============================");

            //Use contains method
            Console.WriteLine(s.Contains("Youtube"));

        }
    }
}
