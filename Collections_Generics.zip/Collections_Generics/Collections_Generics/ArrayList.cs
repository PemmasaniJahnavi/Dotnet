﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Generics
{
    internal partial class ArrayListClass
    {
        public void ArrayListDemo()
        {
            ArrayList al = new ArrayList();
            al.Add(1);
            al.Add(2);
            al.Add("Hello");
            al.Add(15.6f);
            al.Add(12.03);
            al.Add(true);
            
            //print all values
            foreach (var item in al)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("===============================");

            //print specific ones
            Console.WriteLine(al[3]);
            Console.WriteLine(al[4]);
            Console.WriteLine("===============================");

            //add item at specific position
            al.Insert(3, "India");
            foreach (var item in al)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("===============================");

            //remove an element
            al.Remove("Hello");
            al.RemoveAt(5);
            al.RemoveRange(1, 2);
            foreach (var item in al)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("===============================");

            //how to find the count of values
            Console.WriteLine($"Total elements here is {al.Count}");
            Console.WriteLine("===============================");

            //capacity property - no of items that can be stored in array list, grows as 4,8,16,32..
            ArrayList al1 = new ArrayList();
            Console.WriteLine(al1.Capacity);
            al1.Add(10);
            al1.Add(20);
            Console.WriteLine(al1.Capacity);
            al1.TrimToSize();
            Console.WriteLine(al1.Capacity);
        }


    }
}

