﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Generics
{
    internal partial class ArrayListClass
    {
        public void ArrayListDemo1()
        {
            //store product details here (product class created with props)
            ArrayList l1 = new ArrayList();

            //Create object and assign manually
            Product p1 = new Product();
            p1.pid = 101;
            p1.pname = "Mouse";
            p1.price = 1500;
            l1.Add(p1);

            //Use object initializer method directly give values in Add method
            l1.Add(new Product() { pid = 132, pname = "Watch", price = 9000 });
            Product p3 = new Product() { pid = 192, pname = "Table", price = 1000 };
            l1.Add(p3);

            //view product details
            foreach (Product p in l1)
            {
                Console.WriteLine($"{p.pid} {p.pname} {p.price}");
            }
            Console.WriteLine("===============================");

            //After implementing the IComparable interface, we can use sort for complex objects
            l1.Sort();
            Console.WriteLine("Sort using Icomparable");
            foreach (Product p in l1)
            {
                Console.WriteLine($"{p.pid} {p.pname} {p.price}");
            }
            Console.WriteLine("===============================");

            //Sort using IComparer where MySort sorts by the Price        
            MySort ms = new MySort();
            l1.Sort(ms);
            Console.WriteLine("Sort using Icomparer");
            foreach (Product p in l1)
            {
                Console.WriteLine($"{p.pid} {p.pname} {p.price}");
            }
            Console.WriteLine("===============================");

            //Sort using Icomparer where MySort1 sorts by the Name
            MySort1 n = new MySort1();
            l1.Sort(n);

            Console.WriteLine("Sort using Icomparer");
            foreach (Product p in l1)
            {
                Console.WriteLine($"{p.pid} {p.pname} {p.price}");
            }
            Console.WriteLine("===============================");


            //Directly add to array list using Collection Initializer
            ArrayList l2 = new ArrayList();
            {
                new Product() { pid = 1, pname = "Mobile", price = 20000 };
                new Product() { pid = 2, pname = "Laptop", price = 60000 };
            }

            foreach (Product p in l2)
            {
                Console.WriteLine($"{p.pid} {p.pname} {p.price}");
            }
            Console.WriteLine("===============================");

            //Directly with ArrayList declaration
            ArrayList l3 = new ArrayList() { 10, 20, "Hi", "Bye", 10.5f };
            foreach (var p in l3)
            {
                Console.WriteLine(p);
            }
            Console.WriteLine("===============================");

        }
    }
}
