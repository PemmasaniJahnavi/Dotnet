﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Generics
{
    //Using IComparable interface for complex data sort
    internal class Product:IComparable
    {
        public int pid { get; set; }
        public string pname { get; set; }
        public int price { get; set; }

        //This method takes only one object as param as the prop is already available in this class that acts as comparison variable
        public int CompareTo(object obj)//it takes all values of the object
        {
            return price.CompareTo((obj as Product).price);
        }
    }

    //When u want multiple compares create different class for each desirable sort
    class MySort:IComparer
    {
        //This method takes 2 objects as there are no Props in this class and for comparison we need an additional object.
        public int Compare(object x,object y)
        {
            return (x as Product).price.CompareTo((y as Product).price);
        }
    }

    class MySort1 : IComparer
    {
        public int Compare(object x, object y)
        {
            return (x as Product).pname.CompareTo((y as Product).pname);
        }
    }
}
