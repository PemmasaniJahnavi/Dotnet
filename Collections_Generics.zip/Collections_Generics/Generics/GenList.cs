﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    internal class GenList
    {
        //Similar to ArrayList in Collections
        public void ListDemo()
        {
            List<int> l1 = new List<int>();
            l1.Add(21);
            l1.Add(22);
            Console.WriteLine(l1[0] + l1[1]);//no typecast needed

            List<string> l2= new List<string>();
            l2.Add("Jahnavi");
            l2.Add("laasya");
            l2.Add("Kathi");

            foreach (var v in l2)
            {
                Console.WriteLine(v);
            }

        }

        public void ListDemo1()
        {
            //We generally use Generics of a Class like this in realworld
            List<Product> l1 = new List<Product>();

            //Manual assigning
            Product p1 = new Product();
            p1.pid = 102;
            p1.pname = "Mouse";
            p1.price = 1200;
            l1.Add(p1);

            //Use object initializer method directly give values in Add method
            l1.Add(new Product() { pid = 132, pname = "Watch", price = 9000 });
            Product p3 = new Product() { pid = 192, pname = "Table", price = 1000 };
            l1.Add(p3);

            //Collection Initializer
            List<Product> l2 = new List<Product>();
            {
                new Product() { pid = 1, pname = "Mobile", price = 20000 };
                new Product() { pid = 2, pname = "Laptop", price = 60000 };
            }

            //print values
            foreach(var v in l1)
            {
                Console.WriteLine($"{v.pid} {v.pname} {v.price}");
            }
            Console.WriteLine("======================");
            foreach(var v in l2)
            {
                Console.WriteLine($"{v.pid} {v.pname} {v.price}");
            }
        }
    }
}
