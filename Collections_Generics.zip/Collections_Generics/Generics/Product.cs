﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    //Create product class to see real world use of Generics
    internal class Product
    {
        public int pid { get; set; }
        public string pname { get; set; }
        public int price { get; set; }
    }
}
