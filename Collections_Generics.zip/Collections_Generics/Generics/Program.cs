﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ////for List
            //GenList gl=new GenList();
            ////gl.ListDemo();
            //gl.ListDemo1();

            ////for Dictionary
            //GenDictionary gd=new GenDictionary();
            //gd.DictDemo();

            ////Generic Method
            //UserGens gm=new UserGens();
            //gm.Swap(10, 20);
            //gm.Swap("Hi", "hello");

            //Generic class with Constraint
            GenClass<Product> gc=new GenClass<Product>();
            gc.Add(new Product() { pid = 101, pname = "Desktop", price = 3000 });
            gc.Add(new Product() { pid = 102, pname = "CPU", price = 6500 });
            gc.Add(new Product() { pid = 103, pname = "Keyboard", price = 500 });

            Console.WriteLine("Show Values");
            foreach ( var v in gc.Show())
            {
                Console.WriteLine($"{v.pid} {v.pname} {v.price}");
            }
            Console.WriteLine("============================");

            Console.WriteLine("Show Values after a delete");
            foreach (var v in gc.Show())
            {
                Console.WriteLine($"{v.pid} {v.pname} {v.price}");
            }

            ////Generic Class - it implements a generic interface 
            //GenClass1<double> gc1 = new GenClass1<double>();
            //gc1.Swap(15.5, 20.3);



        }
    }
}
