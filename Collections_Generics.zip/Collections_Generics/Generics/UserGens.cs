﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{

    interface IGeneric<T>
    {
        void Swap(T a, T b);
    }

    //Generic method, declare typ enear method, only method can use that type
    internal class UserGens
    {
        public void Swap<T>(T a,T b)
        {
            T c = a;
            a = b; 
            b=c;
            Console.WriteLine(a);
            Console.WriteLine(b);

        }
    }

    //Generic Class, declare type globally that can be used by all methods of this class
    //Giving a generic constraint restricting the type of T to be used.
    internal class GenClass<T> where T:class
    {
        List<T> l1 = new List<T>();

        public void Add(T a)
        {
            l1.Add(a);
        }
        public List<T> Show()
        {
            return l1;
        }
        public void Remove(T a)
        {
            l1.Remove(a);
        }
    }

    //Create a geneic class that implements method of a interface
    internal class GenClass1<T>:IGeneric<T>
    {
        public void Swap(T a, T b)
        {
            T c = a;
            a = b;
            b = c;
            Console.WriteLine(a);
            Console.WriteLine(b);

        }
    }
}
