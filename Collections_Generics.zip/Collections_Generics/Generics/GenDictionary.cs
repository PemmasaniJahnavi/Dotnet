﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    internal class GenDictionary
    {
        //Similar to Hashtable in Collections
        public void DictDemo()
        {
            Dictionary<int,string> d=new Dictionary<int,string>();
            d.Add(1, "Java");
            d.Add(2, "Dotnet");
            d.Add(3, "C#");

            //print using KeyValuePair
            Console.WriteLine("Using KeyvaluePair");
            foreach(KeyValuePair<int,string> kv in d)
            {
                Console.WriteLine($"{kv.Key} {kv.Value}");

            }
            Console.WriteLine("==========================");
            Console.WriteLine("Not Using KeyvaluePair");
            //Directly also it takes withput mentioning KeyValuePair
            foreach (var kv in d)
            {
                Console.WriteLine($"{kv.Key} {kv.Value}");

            }
        }
    }
}
