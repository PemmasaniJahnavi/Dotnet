﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOF
{
    //We have set of algorithms(functions) which are to be decided dynamically during run time like payment method.
    //Simple understanding =Few Steps of Factory+Adapator
    public interface IMyInterface
    {
        void Pay(int x);
    }
     public class PayPal:IMyInterface
     {
        public void Pay(int x)
        {
            Console.WriteLine($"{x} payed through payPal");
        }

     }
     public class CreditCard:IMyInterface
     {
        public void Pay(int x)
        {
            Console.WriteLine($"{x} payed through CrediCard");
        }

    }
     public class PaymentContext :IMyInterface
     {
        IMyInterface obj;
        public void SetPaymentStrategy(IMyInterface o)
        {
            obj = o;
        }
        //or can assign specifically but becomes tough when we have many options.
        //public void SetPaymentStrategy(PayPal o)
        //{
        //    obj = o;
        //}
        //public void SetPaymentStrategy(CreditCard o)
        //{
        //    obj = o;
        //}
        public void Pay(int x)
        {
            obj.Pay(x);
        }

    }
  
}
