﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOF
{
    //When all methods of all classes to be used sequentially use this pattern
    //Hides all complexity, reduces the no of objects users or client has to deal with and makes it easy.
    //Create a class, common method that initializes objects and calls all other methods.

    internal class Login
    {
        public void checkUser()
        {
            Console.WriteLine("Logic to validate User Credentials");
        }
    }
    internal class SearchProducts
    {
        public void Search()
        {
            Console.WriteLine("Search product logic comes here");
        }
    }
    internal class Cart
    {
        public void AddToCart()
        {
            Console.WriteLine("The Product added to cart");
        }
    }
    internal class Payment
    {
        public void Pay()
        {
            Console.WriteLine("Payment logic comes here");
        }
    }
    internal class Email
    {
        public void SendEmail()
        {
            Console.WriteLine("Sending email logic comes here");
        }
    }
    internal class Product
    {
        Login l;
        SearchProducts s;
        Cart c;
        Payment p;
        Email e;
        public Product()
        {
            l = new Login();
            s = new SearchProducts();
            c = new Cart();
            p = new Payment();
            e = new Email();
        }
        public void BuyProduct()
        {          
            l.checkUser();           
            s.Search();           
            c.AddToCart();          
            p.Pay();           
            e.SendEmail();

        }
        
    }
}
