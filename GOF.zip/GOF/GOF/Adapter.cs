﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOF
{
    //Use old & new code without incompatability or if new code with interfaces has to work with old code without interfaces
    //This allows to call method of older code with new code interface.

    //create old,new classes, adaptor class to implement new class interface, there call method of olderclass
    //In main create instance of old class and pass that as arg to adapter class.
    //This can call the old class method using new class interface obj.

    internal class OldClass
    {
        public void ShowDetails(string data)
        {
            Console.WriteLine($"Old class method called {data}");
        }
    }

    internal class OldClass1
    {
        public void ShowDetails(string data)
        {
            Console.WriteLine($"Very Old class method called {data}");
        }
    }

    interface IInterface
    {
       void ShowDetails(string data);
    }
    class Newclass:IInterface
    {
        public void ShowDetails(string data)
        {
            Console.WriteLine($"New class method called {data}");
        }

    }
    internal class Adapter:IInterface
    {
        OldClass obj;
        public Adapter(OldClass o)
        {
            obj = o;
        }
        public void ShowDetails(string data)
        {
            obj.ShowDetails(data);
        }
    }
}
